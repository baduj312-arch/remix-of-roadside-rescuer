"use client"

import { BottomNav } from "@/components/tireno/bottom-nav"
import { JobStatusBadge } from "@/components/tireno/job-status"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowLeft, 
  Star, 
  Wrench, 
  Car, 
  CircleDot, 
  ChevronRight,
  TrendingUp
} from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const historyItems = [
  {
    id: "TRN-A7B3X2",
    provider: "Kwame Auto Services",
    serviceType: "mechanic",
    date: "May 18, 2026",
    amount: 85,
    rating: 5,
    status: "completed" as const,
  },
  {
    id: "TRN-K9M2P1",
    provider: "Speed Towing GH",
    serviceType: "tow",
    date: "May 12, 2026",
    amount: 150,
    rating: 4,
    status: "completed" as const,
  },
  {
    id: "TRN-L4N8Q3",
    provider: "Quick Fix Vulcanizers",
    serviceType: "tire",
    date: "May 5, 2026",
    amount: 45,
    rating: 5,
    status: "completed" as const,
  },
  {
    id: "TRN-R2W6Y5",
    provider: "Joseph Mechanics",
    serviceType: "mechanic",
    date: "April 28, 2026",
    amount: 120,
    rating: 4,
    status: "completed" as const,
  },
  {
    id: "TRN-T8V1Z7",
    provider: "Accra Locksmith Pro",
    serviceType: "locksmith",
    date: "April 15, 2026",
    amount: 60,
    rating: 5,
    status: "completed" as const,
  },
]

const serviceIcons = {
  mechanic: Wrench,
  tow: Car,
  tire: CircleDot,
  locksmith: Wrench,
  fuel: Car,
  battery: Car,
}

export default function HistoryPage() {
  const totalSpent = historyItems.reduce((a, b) => a + b.amount, 0)
  const avgRating = (historyItems.reduce((a, b) => a + b.rating, 0) / historyItems.length).toFixed(1)

  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-bold">Service History</h1>
            <p className="text-xs text-muted-foreground">{historyItems.length} jobs completed</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <TrendingUp className="h-4 w-4" />
                <span className="text-xs">Lifetime Spend</span>
              </div>
              <p className="text-2xl font-bold">GH₵{totalSpent}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Star className="h-4 w-4" />
                <span className="text-xs">Avg. Rating Given</span>
              </div>
              <p className="text-2xl font-bold">{avgRating}</p>
            </CardContent>
          </Card>
        </div>

        {/* History List */}
        <div className="space-y-3">
          {historyItems.map((item) => {
            const Icon = serviceIcons[item.serviceType as keyof typeof serviceIcons] || Wrench
            
            return (
              <Link href={`/history/${item.id}`} key={item.id}>
                <Card className="hover:border-primary/50 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-secondary rounded-full shrink-0">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h3 className="font-semibold truncate">{item.provider}</h3>
                          <JobStatusBadge status={item.status} />
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-muted-foreground">{item.id}</span>
                          <span className="text-xs text-muted-foreground">·</span>
                          <span className="text-xs text-muted-foreground">{item.date}</span>
                        </div>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-3 w-3 ${
                                  i < item.rating
                                    ? "fill-yellow-500 text-yellow-500"
                                    : "text-muted-foreground"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="font-semibold text-primary">GH₵{item.amount}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>

        {/* Dispute Link */}
        <div className="text-center pt-4">
          <Link href="/dispute" className="text-sm text-primary hover:underline">
            Have an issue with a past job? File a dispute
          </Link>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}
