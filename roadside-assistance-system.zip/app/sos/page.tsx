"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { BottomNav } from "@/components/tireno/bottom-nav"
import { ServiceGrid, type ServiceType } from "@/components/tireno/service-types"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, MapPin, Navigation, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function SOSPage() {
  const router = useRouter()
  const [selectedService, setSelectedService] = useState<ServiceType | null>(null)
  const [description, setDescription] = useState("")
  const [isLocating, setIsLocating] = useState(false)
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null)

  const handleGetLocation = () => {
    setIsLocating(true)
    // Simulate getting location
    setTimeout(() => {
      setLocation({ lat: 5.6037, lng: -0.1870 })
      setIsLocating(false)
    }, 1500)
  }

  const handleBroadcast = () => {
    if (selectedService) {
      router.push(`/bidding?service=${selectedService}`)
    }
  }

  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-bold">Request Help</h1>
            <p className="text-xs text-muted-foreground">Select service type</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Alert Banner */}
        <Card className="bg-primary/10 border-primary/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <p className="text-sm">
                Broadcasting will notify all nearby verified providers. You&apos;ll receive bids within 3 minutes.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Service Selection */}
        <section>
          <h2 className="font-semibold mb-3">What do you need?</h2>
          <ServiceGrid selected={selectedService ?? undefined} onSelect={setSelectedService} />
        </section>

        {/* Location */}
        <section>
          <h2 className="font-semibold mb-3">Your Location</h2>
          <Card>
            <CardContent className="p-4">
              {location ? (
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/20 rounded-full">
                    <MapPin className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Location detected</p>
                    <p className="text-sm text-muted-foreground">
                      Accra, Ghana ({location.lat.toFixed(4)}, {location.lng.toFixed(4)})
                    </p>
                  </div>
                </div>
              ) : (
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={handleGetLocation}
                  disabled={isLocating}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  {isLocating ? "Detecting location..." : "Get Current Location"}
                </Button>
              )}
            </CardContent>
          </Card>
        </section>

        {/* Additional Details */}
        <section>
          <h2 className="font-semibold mb-3">Additional Details (Optional)</h2>
          <Textarea
            placeholder="Describe your issue... e.g., Flat tire on the highway, car won't start, etc."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="bg-card"
          />
        </section>

        {/* Broadcast Button */}
        <Button
          size="lg"
          className="w-full h-14 text-lg font-semibold"
          disabled={!selectedService || !location}
          onClick={handleBroadcast}
        >
          <span className="relative flex h-3 w-3 mr-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
          </span>
          Broadcast SOS
        </Button>

        <p className="text-center text-xs text-muted-foreground">
          By broadcasting, you agree to our terms of service and privacy policy
        </p>
      </div>

      <BottomNav />
    </main>
  )
}
