"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  Bell,
  CheckCircle,
  AlertTriangle,
  DollarSign,
  MessageSquare,
  Star,
  Wrench,
  Trash2,
  Check,
} from "lucide-react"

interface Notification {
  id: string
  type: "sos" | "bid" | "payment" | "message" | "rating" | "system"
  title: string
  message: string
  time: string
  read: boolean
  actionUrl?: string
}

const notifications: Notification[] = [
  {
    id: "1",
    type: "bid",
    title: "New Bid Received",
    message: "Kwame Auto Services bid GH₵ 85 for your tire change request",
    time: "2 min ago",
    read: false,
    actionUrl: "/bidding",
  },
  {
    id: "2",
    type: "sos",
    title: "Provider En Route",
    message: "Your mechanic is on the way. ETA: 8 minutes",
    time: "15 min ago",
    read: false,
    actionUrl: "/tracking",
  },
  {
    id: "3",
    type: "payment",
    title: "Payment Successful",
    message: "GH₵ 120.00 paid to Accra Towing for job #TRN-A7B3X2",
    time: "2 hours ago",
    read: true,
  },
  {
    id: "4",
    type: "rating",
    title: "Rate Your Experience",
    message: "How was your service with Kwame Auto Services?",
    time: "3 hours ago",
    read: true,
    actionUrl: "/rating",
  },
  {
    id: "5",
    type: "message",
    title: "New Message",
    message: "Kofi Mechanics: I&apos;m almost at your location",
    time: "Yesterday",
    read: true,
    actionUrl: "/chat",
  },
  {
    id: "6",
    type: "system",
    title: "Trust Score Updated",
    message: "Your trust score increased to 92/100. Great job!",
    time: "2 days ago",
    read: true,
  },
  {
    id: "7",
    type: "system",
    title: "Welcome to Tireno",
    message: "Complete your profile to get started with roadside assistance",
    time: "1 week ago",
    read: true,
    actionUrl: "/profile",
  },
]

export default function NotificationsPage() {
  const [notificationList, setNotificationList] = useState(notifications)
  const [activeTab, setActiveTab] = useState("all")

  const unreadCount = notificationList.filter((n) => !n.read).length

  const getIcon = (type: Notification["type"]) => {
    switch (type) {
      case "sos":
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "bid":
        return <Wrench className="h-5 w-5 text-primary" />
      case "payment":
        return <DollarSign className="h-5 w-5 text-green-500" />
      case "message":
        return <MessageSquare className="h-5 w-5 text-blue-500" />
      case "rating":
        return <Star className="h-5 w-5 text-yellow-500" />
      case "system":
        return <Bell className="h-5 w-5 text-muted-foreground" />
    }
  }

  const markAllRead = () => {
    setNotificationList((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const markAsRead = (id: string) => {
    setNotificationList((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    )
  }

  const deleteNotification = (id: string) => {
    setNotificationList((prev) => prev.filter((n) => n.id !== id))
  }

  const filteredNotifications =
    activeTab === "all"
      ? notificationList
      : activeTab === "unread"
        ? notificationList.filter((n) => !n.read)
        : notificationList.filter((n) => n.type === activeTab)

  return (
    <main className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold">Notifications</h1>
              {unreadCount > 0 && (
                <p className="text-sm text-muted-foreground">
                  {unreadCount} unread
                </p>
              )}
            </div>
          </div>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllRead}>
              <Check className="h-4 w-4 mr-1" />
              Mark all read
            </Button>
          )}
        </div>
      </header>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="p-4">
        <TabsList className="w-full grid grid-cols-4 h-auto p-1">
          <TabsTrigger value="all" className="text-xs py-2">
            All
          </TabsTrigger>
          <TabsTrigger value="unread" className="text-xs py-2">
            Unread
            {unreadCount > 0 && (
              <Badge className="ml-1 h-5 w-5 p-0 justify-center bg-primary text-primary-foreground">
                {unreadCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="sos" className="text-xs py-2">
            SOS
          </TabsTrigger>
          <TabsTrigger value="payment" className="text-xs py-2">
            Payments
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          {filteredNotifications.length === 0 ? (
            <div className="text-center py-12">
              <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No notifications</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredNotifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`transition-all ${
                    !notification.read
                      ? "bg-primary/5 border-primary/20"
                      : "bg-card"
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex gap-3">
                      <div
                        className={`p-2 rounded-full ${
                          !notification.read ? "bg-primary/10" : "bg-secondary"
                        }`}
                      >
                        {getIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold truncate">
                                {notification.title}
                              </p>
                              {!notification.read && (
                                <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                              {notification.message}
                            </p>
                            <p className="text-xs text-muted-foreground mt-2">
                              {notification.time}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 mt-3">
                          {notification.actionUrl && (
                            <Link href={notification.actionUrl}>
                              <Button size="sm" variant="secondary">
                                View
                              </Button>
                            </Link>
                          )}
                          {!notification.read && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => markAsRead(notification.id)}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Mark read
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-destructive hover:text-destructive ml-auto"
                            onClick={() => deleteNotification(notification.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </main>
  )
}
