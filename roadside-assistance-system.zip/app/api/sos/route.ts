import { NextRequest, NextResponse } from 'next/server'

interface SOSRequest {
  serviceType: string
  latitude: number
  longitude: number
  description?: string
  vehicleInfo?: string
}

export async function POST(request: NextRequest) {
  try {
    const body: SOSRequest = await request.json()

    // Validate required fields
    if (!body.serviceType || body.latitude === undefined || body.longitude === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Generate unique SOS ID
    const sosId = `TRN-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
    
    // In a real system, this would:
    // 1. Save to database
    // 2. Trigger real-time broadcast to nearby providers
    // 3. Send notifications
    // 4. Start live tracking

    return NextResponse.json({
      success: true,
      sosId,
      status: 'broadcasting',
      message: 'SOS request created and broadcasting to providers',
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create SOS request' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  const sosId = request.nextUrl.searchParams.get('id')

  if (!sosId) {
    return NextResponse.json(
      { error: 'SOS ID required' },
      { status: 400 }
    )
  }

  // In a real system, fetch from database
  return NextResponse.json({
    sosId,
    status: 'active',
    createdAt: new Date().toISOString(),
  })
}
