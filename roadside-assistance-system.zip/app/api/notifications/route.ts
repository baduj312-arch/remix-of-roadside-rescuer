import { NextRequest, NextResponse } from 'next/server'

interface Notification {
  id: string
  userId: string
  type: 'bid' | 'sos' | 'payment' | 'message' | 'rating' | 'system'
  title: string
  message: string
  read: boolean
  createdAt: string
  data?: Record<string, any>
}

// In-memory store for demo purposes
const notifications = new Map<string, Notification[]>()

export async function GET(request: NextRequest) {
  const userId = request.nextUrl.searchParams.get('userId')
  const unreadOnly = request.nextUrl.searchParams.get('unreadOnly') === 'true'

  if (!userId) {
    return NextResponse.json(
      { error: 'User ID required' },
      { status: 400 }
    )
  }

  let userNotifications = notifications.get(userId) || []

  if (unreadOnly) {
    userNotifications = userNotifications.filter((n) => !n.read)
  }

  return NextResponse.json({
    userId,
    count: userNotifications.length,
    notifications: userNotifications.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ),
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    if (!body.userId || !body.type || !body.title || !body.message) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    if (!notifications.has(body.userId)) {
      notifications.set(body.userId, [])
    }

    const notification: Notification = {
      id: Math.random().toString(36).substring(2, 10),
      userId: body.userId,
      type: body.type,
      title: body.title,
      message: body.message,
      read: false,
      createdAt: new Date().toISOString(),
      data: body.data,
    }

    notifications.get(body.userId)?.push(notification)

    // In a real system:
    // 1. Send push notification
    // 2. Send SMS if opted in
    // 3. Store in database
    // 4. Broadcast via WebSocket

    return NextResponse.json({
      success: true,
      notificationId: notification.id,
      message: 'Notification sent',
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create notification' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()

    if (!body.notificationId || !body.userId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const userNotifications = notifications.get(body.userId)
    if (!userNotifications) {
      return NextResponse.json(
        { error: 'Notifications not found' },
        { status: 404 }
      )
    }

    const notification = userNotifications.find((n) => n.id === body.notificationId)
    if (!notification) {
      return NextResponse.json(
        { error: 'Notification not found' },
        { status: 404 }
      )
    }

    notification.read = body.read ?? true

    return NextResponse.json({
      success: true,
      message: 'Notification updated',
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update notification' },
      { status: 500 }
    )
  }
}
