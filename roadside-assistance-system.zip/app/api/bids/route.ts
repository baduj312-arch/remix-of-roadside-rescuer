import { NextRequest, NextResponse } from 'next/server'

interface Bid {
  sosId: string
  providerId: string
  amount: number
  eta: number // in minutes
  specialNotes?: string
}

// In-memory store for demo purposes
const bids = new Map<string, Bid[]>()

export async function POST(request: NextRequest) {
  try {
    const body: Bid = await request.json()

    if (!body.sosId || !body.providerId || !body.amount || body.eta === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Store bid
    if (!bids.has(body.sosId)) {
      bids.set(body.sosId, [])
    }
    bids.get(body.sosId)?.push({
      ...body,
      providerId: body.providerId,
      amount: body.amount,
      eta: body.eta,
    })

    // In a real system:
    // 1. Validate provider
    // 2. Calculate trust score
    // 3. Store in database
    // 4. Broadcast to driver via WebSocket

    return NextResponse.json({
      success: true,
      bidId: Math.random().toString(36).substring(2, 10),
      status: 'submitted',
      message: 'Bid submitted successfully',
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to submit bid' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  const sosId = request.nextUrl.searchParams.get('sosId')

  if (!sosId) {
    return NextResponse.json(
      { error: 'SOS ID required' },
      { status: 400 }
    )
  }

  const sosBids = bids.get(sosId) || []

  return NextResponse.json({
    sosId,
    bidCount: sosBids.length,
    bids: sosBids.sort((a, b) => a.amount - b.amount),
  })
}
