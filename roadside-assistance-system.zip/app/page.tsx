"use client"

import { BottomNav } from "@/components/tireno/bottom-nav"
import { SOSButton } from "@/components/tireno/sos-button"
import { ServiceGrid } from "@/components/tireno/service-types"
import { ProviderCard, type Provider } from "@/components/tireno/provider-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Shield, Car, Bell, ChevronRight, MapPin } from "lucide-react"
import Link from "next/link"
import { Separator } from "@/components/ui/separator"

const nearbyProviders: Provider[] = [
  {
    id: "1",
    name: "Kwame Auto Services",
    initials: "KA",
    rating: 4.8,
    reviewCount: 156,
    trustScore: 94,
    verified: true,
    serviceType: "mechanic",
    distance: "0.8 km",
    isOnline: true,
  },
  {
    id: "2",
    name: "Speed Towing GH",
    initials: "ST",
    rating: 4.6,
    reviewCount: 89,
    trustScore: 88,
    verified: true,
    serviceType: "tow",
    distance: "1.2 km",
    isOnline: true,
  },
  {
    id: "3",
    name: "Quick Fix Vulcanizers",
    initials: "QF",
    rating: 4.7,
    reviewCount: 203,
    trustScore: 91,
    verified: true,
    serviceType: "tire",
    distance: "1.5 km",
    isOnline: false,
  },
]

export default function HomePage() {
  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
          <div>
            <h1 className="text-xl font-bold text-primary">Tireno</h1>
            <p className="text-xs text-muted-foreground">Roadside Assistance</p>
          </div>
          <Link href="/notifications">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1 right-1 h-2 w-2 bg-primary rounded-full" />
            </Button>
          </Link>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* SOS Section */}
        <section className="text-center py-8">
          <p className="text-muted-foreground mb-4">Need help? Tap SOS</p>
          <div className="flex justify-center">
            <SOSButton />
          </div>
        </section>

        {/* Quick Services */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Quick Services</h2>
            <Link href="/sos" className="text-sm text-primary flex items-center gap-1">
              View all <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <ServiceGrid />
        </section>

        {/* Ride-or-Tow Safety Banner */}
        <Card className="bg-green-500/10 border-green-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-green-500/20 rounded-full">
                <Car className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-green-400">Ride-or-Tow</h3>
                  <Badge className="bg-green-500/20 text-green-400 text-[10px]">
                    Safety
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Your emergency contacts are automatically notified when you request help
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Fake Mechanic Shield */}
        <Card className="bg-blue-500/10 border-blue-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-500/20 rounded-full">
                <Shield className="h-5 w-5 text-blue-500" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-blue-400">Fake Mechanic Shield</h3>
                  <Badge className="bg-blue-500/20 text-blue-400 text-[10px]">
                    Protected
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  All providers are verified with ID, workshop photos, and business licenses
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Nearby Providers */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              <h2 className="font-semibold">Nearby Providers</h2>
            </div>
            <Link href="/providers" className="text-sm text-primary flex items-center gap-1">
              See all <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="space-y-3">
            {nearbyProviders.slice(0, 3).map((provider) => (
              <ProviderCard key={provider.id} provider={provider} variant="compact" />
            ))}
          </div>
        </section>

        {/* Quick Links for Demo */}
        <section className="pt-4">
          <Separator className="mb-4" />
          <div className="space-y-2">
            <Link href="/provider-register">
              <Button variant="outline" className="w-full justify-start">
                Register as a Provider
              </Button>
            </Link>
            <Link href="/provider-dashboard">
              <Button variant="outline" className="w-full justify-start">
                Provider Dashboard
              </Button>
            </Link>
            <Link href="/admin">
              <Button variant="outline" className="w-full justify-start">
                Admin Dashboard (PIN: 1234)
              </Button>
            </Link>
          </div>
        </section>
      </div>

      <BottomNav />
    </main>
  )
}
