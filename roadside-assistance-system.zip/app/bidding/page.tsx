"use client"

import { useState, useEffect, useCallback, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { ProviderCard, type Provider } from "@/components/tireno/provider-card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Radio } from "lucide-react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"

const mockBids: Provider[] = [
  {
    id: "1",
    name: "Kwame Auto Services",
    initials: "KA",
    rating: 4.8,
    reviewCount: 156,
    trustScore: 94,
    verified: true,
    serviceType: "mechanic",
    eta: "4 min",
    price: 85,
    successRate: 98,
    jobsToday: 5,
  },
  {
    id: "2",
    name: "Joseph Mechanics",
    initials: "JM",
    rating: 4.6,
    reviewCount: 89,
    trustScore: 88,
    verified: true,
    serviceType: "mechanic",
    eta: "7 min",
    price: 75,
    successRate: 95,
    jobsToday: 3,
  },
  {
    id: "3",
    name: "Quick Fix Auto",
    initials: "QF",
    rating: 4.5,
    reviewCount: 67,
    trustScore: 85,
    verified: true,
    serviceType: "mechanic",
    eta: "10 min",
    price: 65,
    successRate: 92,
    jobsToday: 2,
  },
]

function BiddingPageContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const service = searchParams.get("service") || "mechanic"
  
  const [timeLeft, setTimeLeft] = useState(180) // 3 minutes
  const [bids, setBids] = useState<Provider[]>([])
  const [jobId] = useState(`TRN-${Math.random().toString(36).substring(2, 8).toUpperCase()}`)

  // Simulate bids coming in
  useEffect(() => {
    const addBid = (index: number) => {
      if (index < mockBids.length) {
        setBids((prev) => [...prev, mockBids[index]])
      }
    }

    const timers = [
      setTimeout(() => addBid(0), 2000),
      setTimeout(() => addBid(1), 4500),
      setTimeout(() => addBid(2), 7000),
    ]

    return () => timers.forEach(clearTimeout)
  }, [])

  // Countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }, [])

  const handleAcceptBid = (providerId: string) => {
    router.push(`/tracking?provider=${providerId}`)
  }

  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          <Link href="/sos">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-lg font-bold">Live Bidding</h1>
            <p className="text-xs text-muted-foreground">{jobId}</p>
          </div>
        </div>
      </header>

      {/* Status Bar */}
      <div className="bg-primary/20 border-b border-primary/30">
        <div className="px-4 py-3 max-w-md mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-primary" />
              </span>
              <div>
                <p className="text-sm font-medium text-primary">Broadcasting SOS</p>
                <p className="text-xs text-muted-foreground">
                  {jobId} · {service.charAt(0).toUpperCase() + service.slice(1)}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold font-mono text-primary">{formatTime(timeLeft)}</p>
              <p className="text-xs text-muted-foreground">remaining</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Bids Count */}
        <div className="flex items-center gap-2">
          <Radio className="h-4 w-4 text-primary" />
          <motion.p
            key={bids.length}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-sm font-medium"
          >
            {bids.length} {bids.length === 1 ? "bid" : "bids"} received
          </motion.p>
        </div>

        {/* Bids List */}
        <div className="space-y-4">
          <AnimatePresence>
            {bids.map((bid, index) => (
              <motion.div
                key={bid.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <ProviderCard
                  provider={bid}
                  variant="bid"
                  showBestValue={index === 0}
                  onAccept={() => handleAcceptBid(bid.id)}
                />
              </motion.div>
            ))}
          </AnimatePresence>

          {bids.length === 0 && (
            <div className="text-center py-12">
              <div className="animate-pulse space-y-4">
                <div className="h-24 bg-secondary rounded-xl" />
                <div className="h-24 bg-secondary rounded-xl opacity-50" />
                <div className="h-24 bg-secondary rounded-xl opacity-25" />
              </div>
              <p className="text-muted-foreground mt-4">Waiting for bids...</p>
            </div>
          )}
        </div>

        {/* Accept Best Bid Button */}
        {bids.length > 0 && (
          <Button
            size="lg"
            className="w-full h-14 text-lg font-semibold"
            onClick={() => handleAcceptBid(bids[0].id)}
          >
            Accept Best Bid · GH₵{bids[0].price}
          </Button>
        )}
      </div>
    </main>
  )
}

export default function BiddingPage() {
  return (
    <Suspense fallback={
      <main className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse">Loading...</div>
      </main>
    }>
      <BiddingPageContent />
    </Suspense>
  )
}
