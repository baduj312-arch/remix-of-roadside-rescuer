"use client"

import { use, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { TrustScoreBar } from "@/components/tireno/provider-card"
import {
  ArrowLeft,
  Star,
  MapPin,
  Phone,
  Clock,
  Shield,
  CheckCircle,
  Wrench,
  Award,
  Calendar,
  ThumbsUp,
  MessageSquare,
  AlertTriangle,
} from "lucide-react"

// Mock provider data
const providerData = {
  "kwame-auto": {
    id: "kwame-auto",
    name: "Kwame Auto Services",
    photo: "/placeholder.svg?height=120&width=120",
    type: "Mechanic",
    rating: 4.8,
    totalRatings: 234,
    trustScore: 94,
    distance: "2.3 km",
    responseTime: "8 min avg",
    jobsCompleted: 1247,
    memberSince: "March 2022",
    verified: true,
    verificationDate: "Jan 2024",
    specialties: ["Engine Repair", "Tire Change", "Battery Jump", "Oil Change"],
    about:
      "Professional auto mechanic with over 15 years of experience. Specialized in both local and imported vehicles. Fast, reliable, and honest service guaranteed.",
    stats: {
      successRate: 98,
      onTimeRate: 95,
      repeatCustomers: 67,
    },
    reviews: [
      {
        id: "1",
        name: "Ama K.",
        rating: 5,
        date: "2 days ago",
        comment:
          "Excellent service! Fixed my flat tire in under 20 minutes. Very professional.",
      },
      {
        id: "2",
        name: "Kofi M.",
        rating: 5,
        date: "1 week ago",
        comment:
          "Kwame is the best mechanic I&apos;ve ever used. Fair prices and honest work.",
      },
      {
        id: "3",
        name: "Yaw A.",
        rating: 4,
        date: "2 weeks ago",
        comment: "Good service, arrived on time. Would recommend.",
      },
    ],
    pricing: {
      "Tire Change": "GH₵ 50 - 80",
      "Battery Jump": "GH₵ 40 - 60",
      "Oil Change": "GH₵ 80 - 120",
      "Engine Diagnostic": "GH₵ 100 - 150",
    },
  },
}

export default function ProviderDetailPage({ 
  params 
}: { 
  params: Promise<{ id: string }> 
}) {
  const resolvedParams = use(params)
  const [activeTab, setActiveTab] = useState("overview")

  // Get provider data or use default
  const provider =
    providerData[resolvedParams.id as keyof typeof providerData] ||
    providerData["kwame-auto"]

  return (
    <main className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 p-4">
          <Link href="/providers">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">Provider Profile</h1>
        </div>
      </header>

      {/* Provider Header */}
      <div className="p-4 border-b border-border">
        <div className="flex gap-4">
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center">
              <Wrench className="h-8 w-8 text-muted-foreground" />
            </div>
            {provider.verified && (
              <div className="absolute -bottom-1 -right-1 p-1 bg-green-500 rounded-full">
                <CheckCircle className="h-4 w-4 text-white" />
              </div>
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold">{provider.name}</h2>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="secondary">{provider.type}</Badge>
              {provider.verified && (
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                  <Shield className="h-3 w-3 mr-1" />
                  Verified
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                {provider.rating} ({provider.totalRatings})
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {provider.distance}
              </span>
            </div>
          </div>
        </div>

        {/* Trust Score */}
        <div className="mt-4">
          <TrustScoreBar
            score={provider.trustScore}
            showBreakdown={true}
            rating={provider.rating}
            successRate={provider.stats.successRate}
            responseTime={provider.stats.onTimeRate}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mt-4">
          <Button className="flex-1">
            <Phone className="h-4 w-4 mr-2" />
            Call
          </Button>
          <Button variant="secondary" className="flex-1">
            <MessageSquare className="h-4 w-4 mr-2" />
            Message
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="p-4">
        <TabsList className="w-full grid grid-cols-3 h-auto p-1">
          <TabsTrigger value="overview" className="text-xs py-2">
            Overview
          </TabsTrigger>
          <TabsTrigger value="reviews" className="text-xs py-2">
            Reviews
          </TabsTrigger>
          <TabsTrigger value="pricing" className="text-xs py-2">
            Pricing
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="mt-4 space-y-4">
          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3">
            <Card>
              <CardContent className="p-3 text-center">
                <Award className="h-5 w-5 text-primary mx-auto mb-1" />
                <p className="text-lg font-bold">{provider.jobsCompleted}</p>
                <p className="text-xs text-muted-foreground">Jobs Done</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <Clock className="h-5 w-5 text-primary mx-auto mb-1" />
                <p className="text-lg font-bold">{provider.responseTime}</p>
                <p className="text-xs text-muted-foreground">Response</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <ThumbsUp className="h-5 w-5 text-primary mx-auto mb-1" />
                <p className="text-lg font-bold">
                  {provider.stats.repeatCustomers}%
                </p>
                <p className="text-xs text-muted-foreground">Repeat</p>
              </CardContent>
            </Card>
          </div>

          {/* About */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-2">About</h3>
              <p className="text-sm text-muted-foreground">{provider.about}</p>
            </CardContent>
          </Card>

          {/* Verification */}
          <Card className="bg-green-500/10 border-green-500/30">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-green-400">
                    Fake Mechanic Shield Verified
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    ID verified, background checked, and skills assessed.
                    Verified on {provider.verificationDate}.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Specialties */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">Specialties</h3>
              <div className="flex flex-wrap gap-2">
                {provider.specialties.map((specialty) => (
                  <Badge key={specialty} variant="secondary">
                    {specialty}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Performance */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <h3 className="font-semibold">Performance</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Success Rate</span>
                    <span className="font-medium">
                      {provider.stats.successRate}%
                    </span>
                  </div>
                  <Progress
                    value={provider.stats.successRate}
                    className="h-2"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>On-Time Arrival</span>
                    <span className="font-medium">
                      {provider.stats.onTimeRate}%
                    </span>
                  </div>
                  <Progress value={provider.stats.onTimeRate} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Repeat Customers</span>
                    <span className="font-medium">
                      {provider.stats.repeatCustomers}%
                    </span>
                  </div>
                  <Progress
                    value={provider.stats.repeatCustomers}
                    className="h-2"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Member Info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">Member since {provider.memberSince}</p>
                  <p className="text-sm text-muted-foreground">
                    {provider.jobsCompleted} jobs completed on Tireno
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reviews Tab */}
        <TabsContent value="reviews" className="mt-4 space-y-4">
          {/* Rating Summary */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="text-center">
                  <p className="text-4xl font-bold">{provider.rating}</p>
                  <div className="flex items-center justify-center gap-0.5 mt-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-4 w-4 ${
                          star <= Math.round(provider.rating)
                            ? "text-yellow-500 fill-yellow-500"
                            : "text-muted-foreground"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {provider.totalRatings} reviews
                  </p>
                </div>
                <div className="flex-1 space-y-1">
                  {[5, 4, 3, 2, 1].map((rating) => (
                    <div key={rating} className="flex items-center gap-2">
                      <span className="text-xs w-3">{rating}</span>
                      <Progress
                        value={rating === 5 ? 75 : rating === 4 ? 20 : 5}
                        className="h-2 flex-1"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Reviews List */}
          {provider.reviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold">{review.name}</p>
                    <div className="flex items-center gap-1 mt-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-3 w-3 ${
                            star <= review.rating
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-muted-foreground"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {review.date}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {review.comment}
                </p>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Pricing Tab */}
        <TabsContent value="pricing" className="mt-4 space-y-4">
          <Card>
            <CardContent className="p-0 divide-y divide-border">
              {Object.entries(provider.pricing).map(([service, price]) => (
                <div
                  key={service}
                  className="flex items-center justify-between p-4"
                >
                  <div className="flex items-center gap-3">
                    <Wrench className="h-5 w-5 text-muted-foreground" />
                    <span className="font-medium">{service}</span>
                  </div>
                  <span className="text-primary font-semibold">{price}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="bg-yellow-500/10 border-yellow-500/30">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-400">
                    Prices are estimates
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Final price may vary based on the specific issue, parts
                    needed, and location. Always confirm the bid amount before
                    accepting.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Button className="w-full" size="lg">
            Request Service
          </Button>
        </TabsContent>
      </Tabs>
    </main>
  )
}
