"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  LayoutDashboard, 
  Users, 
  AlertTriangle, 
  Settings,
  Activity,
  DollarSign,
  TrendingUp,
  Clock,
  Star,
  Shield,
  FileText,
  CheckCircle,
  XCircle,
  AlertCircle,
  MapPin,
  Send,
  Calendar
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"

const recentJobs = [
  { id: "TRN-A7B3X2", provider: "Kwame Auto", status: "completed", amount: 85 },
  { id: "TRN-K9M2P1", provider: "Speed Towing", status: "in_progress", amount: 150 },
  { id: "TRN-L4N8Q3", provider: "Quick Fix", status: "pending", amount: 45 },
]

const verificationQueue = [
  {
    id: "1",
    name: "Joseph Mechanics",
    documents: { id: true, workshop: true, license: false },
    submitted: "2 hours ago",
  },
  {
    id: "2",
    name: "Accra Auto Pro",
    documents: { id: true, workshop: true, license: true },
    submitted: "5 hours ago",
  },
]

const fraudAlerts = [
  { id: "1", type: "gps_spoof", provider: "Unknown User", severity: "high" },
  { id: "2", type: "duplicate", provider: "Test Account", severity: "medium" },
]

const payoutList = [
  { provider: "Kwame Auto Services", amount: 1250, status: "paid" },
  { provider: "Speed Towing GH", amount: 890, status: "processing" },
  { provider: "Quick Fix Vulcanizers", amount: 650, status: "paid" },
]

const peakHoursData = [
  { hour: "6AM", value: 20 },
  { hour: "9AM", value: 85 },
  { hour: "12PM", value: 60 },
  { hour: "3PM", value: 45 },
  { hour: "6PM", value: 90 },
  { hour: "9PM", value: 70 },
]

const recentBroadcasts = [
  { message: "System maintenance tonight 12AM-2AM", date: "May 18", audience: "All" },
  { message: "New pricing update for tow services", date: "May 15", audience: "Providers" },
]

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [pin, setPin] = useState("")
  const [activeTab, setActiveTab] = useState("overview")
  const [broadcastMessage, setBroadcastMessage] = useState("")
  const [broadcastType, setBroadcastType] = useState("")
  const [broadcastRegion, setBroadcastRegion] = useState("")

  const handlePinSubmit = () => {
    if (pin === "1234") {
      setIsAuthenticated(true)
    } else {
      setPin("")
    }
  }

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-sm">
          <CardHeader className="text-center">
            <CardTitle>Admin Access</CardTitle>
            <p className="text-sm text-muted-foreground">Enter PIN to continue</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <InputOTP maxLength={4} value={pin} onChange={setPin}>
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                </InputOTPGroup>
              </InputOTP>
            </div>
            <Button className="w-full" onClick={handlePinSubmit} disabled={pin.length !== 4}>
              Access Dashboard
            </Button>
            <Link href="/" className="block text-center text-sm text-muted-foreground hover:underline">
              Back to Home
            </Link>
          </CardContent>
        </Card>
      </main>
    )
  }

  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between px-4 py-3 max-w-4xl mx-auto">
          <div>
            <h1 className="text-lg font-bold">Admin Dashboard</h1>
            <p className="text-xs text-muted-foreground">Tireno Management</p>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsAuthenticated(false)}>
            Logout
          </Button>
        </div>
      </header>

      <div className="px-4 py-6 max-w-4xl mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full grid grid-cols-5 mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="providers">Providers</TabsTrigger>
            <TabsTrigger value="finance">Finance</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Activity className="h-4 w-4" />
                    <span className="text-xs">Active Jobs</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-2xl font-bold">24</p>
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
                    </span>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Users className="h-4 w-4" />
                    <span className="text-xs">Online Providers</span>
                  </div>
                  <p className="text-2xl font-bold">156</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <DollarSign className="h-4 w-4" />
                    <span className="text-xs">Today Revenue</span>
                  </div>
                  <p className="text-2xl font-bold">GH₵4,280</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <TrendingUp className="h-4 w-4" />
                    <span className="text-xs">Commission</span>
                  </div>
                  <p className="text-2xl font-bold">10%</p>
                </CardContent>
              </Card>
            </div>

            {/* Live Map Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Live SOS Map</CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className="h-48 bg-secondary rounded-lg relative overflow-hidden"
                  style={{
                    backgroundImage: `
                      linear-gradient(rgba(255,107,44,0.1) 1px, transparent 1px),
                      linear-gradient(90deg, rgba(255,107,44,0.1) 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px'
                  }}
                >
                  {/* Simulated dots */}
                  <div className="absolute top-1/4 left-1/4 h-3 w-3 bg-primary rounded-full animate-pulse" />
                  <div className="absolute top-1/2 left-1/2 h-3 w-3 bg-green-500 rounded-full animate-pulse" />
                  <div className="absolute top-3/4 left-2/3 h-3 w-3 bg-primary rounded-full animate-pulse" />
                  <div className="absolute top-1/3 left-3/4 h-3 w-3 bg-yellow-500 rounded-full animate-pulse" />
                </div>
              </CardContent>
            </Card>

            {/* KPIs */}
            <div className="grid md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Response Time</span>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-lg font-bold mb-2">2.3 min avg</p>
                  <Progress value={85} className="h-2" />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Completion Rate</span>
                    <CheckCircle className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-lg font-bold mb-2">94.2%</p>
                  <Progress value={94} className="h-2" />
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Satisfaction</span>
                    <Star className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-lg font-bold mb-2">4.7 / 5</p>
                  <Progress value={94} className="h-2" />
                </CardContent>
              </Card>
            </div>

            {/* Recent Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentJobs.map((job) => (
                    <div key={job.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                      <div>
                        <p className="font-medium text-sm">{job.id}</p>
                        <p className="text-xs text-muted-foreground">{job.provider}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge 
                          variant="secondary"
                          className={cn(
                            job.status === "completed" && "bg-green-500/20 text-green-400",
                            job.status === "in_progress" && "bg-primary/20 text-primary",
                            job.status === "pending" && "bg-yellow-500/20 text-yellow-400"
                          )}
                        >
                          {job.status.replace("_", " ")}
                        </Badge>
                        <span className="font-medium">GH₵{job.amount}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Providers Tab */}
          <TabsContent value="providers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Verification Queue</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {verificationQueue.map((provider) => (
                  <div key={provider.id} className="p-4 bg-secondary rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold">{provider.name}</h4>
                      <span className="text-xs text-muted-foreground">{provider.submitted}</span>
                    </div>
                    <div className="flex gap-2 mb-3">
                      <Badge variant="secondary" className={provider.documents.id ? "bg-green-500/20 text-green-400" : ""}>
                        ID {provider.documents.id ? "✓" : "✗"}
                      </Badge>
                      <Badge variant="secondary" className={provider.documents.workshop ? "bg-green-500/20 text-green-400" : ""}>
                        Workshop {provider.documents.workshop ? "✓" : "✗"}
                      </Badge>
                      <Badge variant="secondary" className={provider.documents.license ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}>
                        License {provider.documents.license ? "✓" : "✗"}
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="flex-1">Approve</Button>
                      <Button size="sm" variant="destructive" className="flex-1">Reject</Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                  Fraud Alerts
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {fraudAlerts.map((alert) => (
                  <div 
                    key={alert.id} 
                    className={cn(
                      "p-3 rounded-lg flex items-center justify-between",
                      alert.severity === "high" ? "bg-red-500/10 border border-red-500/30" : "bg-yellow-500/10 border border-yellow-500/30"
                    )}
                  >
                    <div>
                      <p className={cn(
                        "font-medium text-sm",
                        alert.severity === "high" ? "text-red-400" : "text-yellow-400"
                      )}>
                        {alert.type === "gps_spoof" ? "GPS Spoofing Detected" : "Duplicate Account"}
                      </p>
                      <p className="text-xs text-muted-foreground">{alert.provider}</p>
                    </div>
                    <Button size="sm" variant="outline">Review</Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Finance Tab */}
          <TabsContent value="finance" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Total Revenue (May)</p>
                  <p className="text-2xl font-bold text-primary">GH₵128,450</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Platform Earnings</p>
                  <p className="text-2xl font-bold">GH₵12,845</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Provider Payouts</p>
                  <p className="text-2xl font-bold">GH₵115,605</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Revenue by Region</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { region: "Accra", percentage: 57, amount: "73,217" },
                  { region: "Kumasi", percentage: 27, amount: "34,682" },
                  { region: "Nairobi", percentage: 10, amount: "12,845" },
                  { region: "Other", percentage: 6, amount: "7,707" },
                ].map((item) => (
                  <div key={item.region} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{item.region}</span>
                      <span className="text-muted-foreground">GH₵{item.amount} ({item.percentage}%)</span>
                    </div>
                    <Progress value={item.percentage} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Provider Payouts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {payoutList.map((payout, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <p className="font-medium text-sm">{payout.provider}</p>
                    <div className="flex items-center gap-3">
                      <Badge 
                        variant="secondary"
                        className={payout.status === "paid" ? "bg-green-500/20 text-green-400" : "bg-yellow-500/20 text-yellow-400"}
                      >
                        {payout.status}
                      </Badge>
                      <span className="font-medium">GH₵{payout.amount}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Total Users</p>
                  <p className="text-2xl font-bold">12,847</p>
                  <p className="text-xs text-green-500">+234 this week</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Active Providers</p>
                  <p className="text-2xl font-bold">487</p>
                  <p className="text-xs text-green-500">+18 this week</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Jobs This Month</p>
                  <p className="text-2xl font-bold">3,892</p>
                  <p className="text-xs text-green-500">+12% vs last month</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Peak Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between h-32 gap-2">
                  {peakHoursData.map((item) => (
                    <div key={item.hour} className="flex-1 flex flex-col items-center gap-2">
                      <div 
                        className={cn(
                          "w-full rounded-t transition-all",
                          item.value > 70 ? "bg-primary" : item.value > 50 ? "bg-primary/60" : "bg-primary/30"
                        )}
                        style={{ height: `${item.value}%` }}
                      />
                      <span className="text-xs text-muted-foreground">{item.hour}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-red-500/10 border-red-500/30">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2 text-red-400">
                  <AlertCircle className="h-4 w-4" />
                  Provider Shortage Zones
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-red-500/10 rounded">
                  <span className="text-sm">Tema Industrial Area</span>
                  <Badge variant="destructive">Critical</Badge>
                </div>
                <div className="flex items-center justify-between p-2 bg-yellow-500/10 rounded">
                  <span className="text-sm">Kasoa</span>
                  <Badge className="bg-yellow-500/20 text-yellow-400">Low</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Broadcast Message</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Type</label>
                    <Select value={broadcastType} onValueChange={setBroadcastType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="announcement">Announcement</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="promotion">Promotion</SelectItem>
                        <SelectItem value="alert">Alert</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Region</label>
                    <Select value={broadcastRegion} onValueChange={setBroadcastRegion}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Regions</SelectItem>
                        <SelectItem value="accra">Accra</SelectItem>
                        <SelectItem value="kumasi">Kumasi</SelectItem>
                        <SelectItem value="nairobi">Nairobi</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Badge variant="secondary" className="cursor-pointer">All Users</Badge>
                  <Badge variant="outline" className="cursor-pointer">Drivers Only</Badge>
                  <Badge variant="outline" className="cursor-pointer">Providers Only</Badge>
                </div>

                <Textarea
                  placeholder="Enter your message..."
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  rows={4}
                />

                <div className="flex gap-2">
                  <Button className="flex-1 gap-2">
                    <Send className="h-4 w-4" />
                    Broadcast Now
                  </Button>
                  <Button variant="secondary" className="gap-2">
                    <Calendar className="h-4 w-4" />
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Broadcasts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentBroadcasts.map((broadcast, index) => (
                  <div key={index} className="p-3 bg-secondary rounded-lg">
                    <p className="text-sm">{broadcast.message}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      <span>{broadcast.date}</span>
                      <span>·</span>
                      <span>{broadcast.audience}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Admin Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-lg">
        <div className="flex items-center justify-around py-2 px-4 max-w-4xl mx-auto">
          {[
            { tab: "overview", icon: LayoutDashboard, label: "Dashboard" },
            { tab: "providers", icon: Users, label: "Providers" },
            { tab: "alerts", icon: AlertTriangle, label: "Disputes" },
            { tab: "finance", icon: Settings, label: "Settings" },
          ].map((item) => (
            <button
              key={item.tab}
              onClick={() => setActiveTab(item.tab)}
              className={cn(
                "flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors",
                activeTab === item.tab
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </main>
  )
}
