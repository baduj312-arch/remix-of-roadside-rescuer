"use client"

import { useState } from "react"
import { BottomNav } from "@/components/tireno/bottom-nav"
import { ProviderCard, type Provider } from "@/components/tireno/provider-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Filter } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

const filters = ["All", "Mechanic", "Tow Truck", "Vulcanizer", "Locksmith", "Fuel"]

const allProviders: Provider[] = [
  {
    id: "1",
    name: "Kwame Auto Services",
    initials: "KA",
    rating: 4.8,
    reviewCount: 156,
    trustScore: 94,
    verified: true,
    serviceType: "mechanic",
    distance: "0.8 km",
    isOnline: true,
  },
  {
    id: "2",
    name: "Speed Towing GH",
    initials: "ST",
    rating: 4.6,
    reviewCount: 89,
    trustScore: 88,
    verified: true,
    serviceType: "tow",
    distance: "1.2 km",
    isOnline: true,
  },
  {
    id: "3",
    name: "Quick Fix Vulcanizers",
    initials: "QF",
    rating: 4.7,
    reviewCount: 203,
    trustScore: 91,
    verified: true,
    serviceType: "tire",
    distance: "1.5 km",
    isOnline: false,
  },
  {
    id: "4",
    name: "Accra Locksmith Pro",
    initials: "AL",
    rating: 4.5,
    reviewCount: 67,
    trustScore: 85,
    verified: true,
    serviceType: "locksmith",
    distance: "2.1 km",
    isOnline: true,
  },
  {
    id: "5",
    name: "Joseph Mechanics",
    initials: "JM",
    rating: 4.4,
    reviewCount: 112,
    trustScore: 82,
    verified: true,
    serviceType: "mechanic",
    distance: "2.8 km",
    isOnline: true,
  },
]

export default function ProvidersPage() {
  const [activeFilter, setActiveFilter] = useState("All")

  const filteredProviders = allProviders.filter((provider) => {
    if (activeFilter === "All") return true
    const filterMap: Record<string, string> = {
      "Mechanic": "mechanic",
      "Tow Truck": "tow",
      "Vulcanizer": "tire",
      "Locksmith": "locksmith",
      "Fuel": "fuel",
    }
    return provider.serviceType === filterMap[activeFilter]
  })

  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-lg font-bold">Nearby Providers</h1>
              <p className="text-xs text-muted-foreground">{filteredProviders.length} available</p>
            </div>
          </div>
          <Button variant="ghost" size="icon">
            <Filter className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Filters */}
      <div className="border-b border-border bg-card/50">
        <div className="px-4 py-3 max-w-md mx-auto">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
            {filters.map((filter) => (
              <Button
                key={filter}
                variant={activeFilter === filter ? "default" : "secondary"}
                size="sm"
                className={cn(
                  "shrink-0",
                  activeFilter === filter && "bg-primary text-primary-foreground"
                )}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="px-4 py-6 max-w-md mx-auto">
        {/* Stats */}
        <div className="flex gap-4 mb-6">
          <Badge variant="secondary" className="bg-green-500/20 text-green-400">
            {allProviders.filter((p) => p.isOnline).length} Online
          </Badge>
          <Badge variant="secondary">
            Avg. Trust Score: {Math.round(allProviders.reduce((a, b) => a + b.trustScore, 0) / allProviders.length)}
          </Badge>
        </div>

        {/* Provider List */}
        <div className="space-y-4">
          {filteredProviders.map((provider) => (
            <Link key={provider.id} href={`/provider/${provider.id === "1" ? "kwame-auto" : provider.id}`}>
              <ProviderCard provider={provider} variant="detailed" />
            </Link>
          ))}
        </div>

        {filteredProviders.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No providers found for this category</p>
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}
