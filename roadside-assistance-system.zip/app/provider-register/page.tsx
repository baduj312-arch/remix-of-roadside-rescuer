"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowLeft, 
  Upload, 
  Shield, 
  CheckCircle, 
  Clock,
  FileText,
  Camera,
  IdCard
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

const serviceCategories = [
  "Mechanic",
  "Tow Truck Operator",
  "Vulcanizer",
  "Locksmith",
  "Fuel Delivery",
  "Battery Service",
]

const workDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

export default function ProviderRegisterPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    businessName: "",
    category: "",
    yearsInBusiness: "",
    serviceRadius: "",
    address: "",
    basePrice: "",
    openTime: "08:00",
    closeTime: "18:00",
    activeDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    surgeNight: false,
    surgeRemote: false,
  })
  const [documents, setDocuments] = useState({
    nationalId: false,
    workshopPhoto: false,
    businessLicence: false,
  })
  const [caseRef] = useState(`PRV-${Math.random().toString(36).substring(2, 8).toUpperCase()}`)

  const progress = (step / 4) * 100

  const handleNext = () => {
    if (step < 4) setStep(step + 1)
  }

  const handleBack = () => {
    if (step > 1) setStep(step - 1)
  }

  const toggleDay = (day: string) => {
    setFormData((prev) => ({
      ...prev,
      activeDays: prev.activeDays.includes(day)
        ? prev.activeDays.filter((d) => d !== day)
        : [...prev.activeDays, day],
    }))
  }

  return (
    <main className="min-h-screen pb-6">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          {step > 1 ? (
            <Button variant="ghost" size="icon" onClick={handleBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          ) : (
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
          )}
          <div>
            <h1 className="text-lg font-bold">Provider Registration</h1>
            <p className="text-xs text-muted-foreground">Step {step} of 4</p>
          </div>
        </div>
      </header>

      {/* Progress */}
      <div className="px-4 py-4 max-w-md mx-auto">
        <div className="flex gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={cn(
                "h-2 flex-1 rounded-full transition-colors",
                s <= step ? "bg-primary" : "bg-secondary"
              )}
            />
          ))}
        </div>
      </div>

      <div className="px-4 pb-6 max-w-md mx-auto space-y-6">
        {/* Step 1: Business Info */}
        {step === 1 && (
          <>
            <h2 className="text-xl font-semibold">Business Information</h2>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Business Name</Label>
                <Input
                  placeholder="e.g., Kwame Auto Services"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  className="bg-card"
                />
              </div>

              <div className="space-y-2">
                <Label>Service Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger className="bg-card">
                    <SelectValue placeholder="Select your service" />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceCategories.map((cat) => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Years in Business</Label>
                  <Input
                    type="number"
                    placeholder="e.g., 5"
                    value={formData.yearsInBusiness}
                    onChange={(e) => setFormData({ ...formData, yearsInBusiness: e.target.value })}
                    className="bg-card"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Service Radius (km)</Label>
                  <Input
                    type="number"
                    placeholder="e.g., 10"
                    value={formData.serviceRadius}
                    onChange={(e) => setFormData({ ...formData, serviceRadius: e.target.value })}
                    className="bg-card"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Workshop Address</Label>
                <Input
                  placeholder="Full address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="bg-card"
                />
              </div>

              <div className="space-y-2">
                <Label>Base Service Price (GH₵)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 50"
                  value={formData.basePrice}
                  onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })}
                  className="bg-card"
                />
              </div>
            </div>

            <Button size="lg" className="w-full" onClick={handleNext}>
              Continue
            </Button>
          </>
        )}

        {/* Step 2: Pricing & Hours */}
        {step === 2 && (
          <>
            <h2 className="text-xl font-semibold">Pricing & Hours</h2>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Opening Time</Label>
                  <Input
                    type="time"
                    value={formData.openTime}
                    onChange={(e) => setFormData({ ...formData, openTime: e.target.value })}
                    className="bg-card"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Closing Time</Label>
                  <Input
                    type="time"
                    value={formData.closeTime}
                    onChange={(e) => setFormData({ ...formData, closeTime: e.target.value })}
                    className="bg-card"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Working Days</Label>
                <div className="flex gap-2 flex-wrap">
                  {workDays.map((day) => (
                    <Button
                      key={day}
                      variant={formData.activeDays.includes(day) ? "default" : "secondary"}
                      size="sm"
                      onClick={() => toggleDay(day)}
                    >
                      {day}
                    </Button>
                  ))}
                </div>
              </div>

              <Card>
                <CardContent className="p-4 space-y-4">
                  <h3 className="font-semibold">Surge Pricing</h3>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Late Night (10PM - 6AM)</p>
                      <p className="text-sm text-muted-foreground">+25% base price</p>
                    </div>
                    <Switch
                      checked={formData.surgeNight}
                      onCheckedChange={(checked) => setFormData({ ...formData, surgeNight: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Remote Area</p>
                      <p className="text-sm text-muted-foreground">+15% for {">"} 5km</p>
                    </div>
                    <Switch
                      checked={formData.surgeRemote}
                      onCheckedChange={(checked) => setFormData({ ...formData, surgeRemote: checked })}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Button size="lg" className="w-full" onClick={handleNext}>
              Continue
            </Button>
          </>
        )}

        {/* Step 3: Documents */}
        {step === 3 && (
          <>
            <Card className="bg-blue-500/10 border-blue-500/30">
              <CardContent className="p-4 flex items-start gap-3">
                <Shield className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-blue-400">Fake Mechanic Shield</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Upload your documents to get verified and earn the trusted provider badge.
                  </p>
                </div>
              </CardContent>
            </Card>

            <h2 className="text-xl font-semibold">Upload Documents</h2>

            <div className="space-y-3">
              {/* National ID */}
              <Card 
                className={cn(
                  "cursor-pointer transition-colors",
                  documents.nationalId ? "border-green-500" : "hover:border-primary/50"
                )}
                onClick={() => setDocuments({ ...documents, nationalId: true })}
              >
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-full",
                    documents.nationalId ? "bg-green-500/20" : "bg-secondary"
                  )}>
                    <IdCard className={cn(
                      "h-5 w-5",
                      documents.nationalId ? "text-green-500" : "text-muted-foreground"
                    )} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">National ID</p>
                    <p className="text-sm text-muted-foreground">Ghana Card or Passport</p>
                  </div>
                  {documents.nationalId ? (
                    <Badge className="bg-green-500/20 text-green-400">Uploaded</Badge>
                  ) : (
                    <Upload className="h-5 w-5 text-muted-foreground" />
                  )}
                </CardContent>
              </Card>

              {/* Workshop Photo */}
              <Card 
                className={cn(
                  "cursor-pointer transition-colors",
                  documents.workshopPhoto ? "border-green-500" : "hover:border-primary/50"
                )}
                onClick={() => setDocuments({ ...documents, workshopPhoto: true })}
              >
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-full",
                    documents.workshopPhoto ? "bg-green-500/20" : "bg-secondary"
                  )}>
                    <Camera className={cn(
                      "h-5 w-5",
                      documents.workshopPhoto ? "text-green-500" : "text-muted-foreground"
                    )} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Workshop Photo</p>
                    <p className="text-sm text-muted-foreground">Clear photo of your workspace</p>
                  </div>
                  {documents.workshopPhoto ? (
                    <Badge className="bg-green-500/20 text-green-400">Uploaded</Badge>
                  ) : (
                    <Upload className="h-5 w-5 text-muted-foreground" />
                  )}
                </CardContent>
              </Card>

              {/* Business Licence */}
              <Card 
                className={cn(
                  "cursor-pointer transition-colors",
                  documents.businessLicence ? "border-green-500" : "hover:border-primary/50"
                )}
                onClick={() => setDocuments({ ...documents, businessLicence: true })}
              >
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={cn(
                    "p-3 rounded-full",
                    documents.businessLicence ? "bg-green-500/20" : "bg-secondary"
                  )}>
                    <FileText className={cn(
                      "h-5 w-5",
                      documents.businessLicence ? "text-green-500" : "text-muted-foreground"
                    )} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Business License</p>
                    <p className="text-sm text-muted-foreground">Registration certificate</p>
                  </div>
                  {documents.businessLicence ? (
                    <Badge className="bg-green-500/20 text-green-400">Uploaded</Badge>
                  ) : (
                    <Badge variant="secondary">Pending</Badge>
                  )}
                </CardContent>
              </Card>
            </div>

            <Button 
              size="lg" 
              className="w-full" 
              onClick={handleNext}
              disabled={!documents.nationalId || !documents.workshopPhoto}
            >
              Submit for Review
            </Button>
          </>
        )}

        {/* Step 4: Confirmation */}
        {step === 4 && (
          <div className="text-center space-y-6 py-8">
            <div className="flex justify-center">
              <div className="p-4 bg-green-500/20 rounded-full">
                <Shield className="h-12 w-12 text-green-500" />
              </div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-xl font-semibold">Application Submitted!</h2>
              <p className="text-muted-foreground">Reference: {caseRef}</p>
            </div>

            <Card className="bg-blue-500/10 border-blue-500/30 text-left">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="h-5 w-5 text-blue-500" />
                  <p className="font-medium text-blue-400">48-hour Review</p>
                </div>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>Our team will verify your documents</li>
                  <li>You&apos;ll receive an SMS when approved</li>
                  <li>Re-verification required every 6 months</li>
                </ul>
              </CardContent>
            </Card>

            <Button 
              size="lg" 
              className="w-full"
              onClick={() => router.push("/provider-dashboard")}
            >
              Go to Provider Dashboard
            </Button>
          </div>
        )}
      </div>
    </main>
  )
}
