"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  Bell,
  Globe,
  Shield,
  Moon,
  Smartphone,
  MapPin,
  CreditCard,
  HelpCircle,
  LogOut,
  ChevronRight,
  Eye,
  Volume2,
  Vibrate,
} from "lucide-react"

export default function SettingsPage() {
  const [notifications, setNotifications] = useState({
    push: true,
    sms: true,
    email: false,
    bidAlerts: true,
    promotions: false,
  })

  const [preferences, setPreferences] = useState({
    darkMode: true,
    soundEffects: true,
    hapticFeedback: true,
    autoDetectLocation: true,
    showTrustScore: true,
  })

  return (
    <main className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 p-4">
          <Link href="/profile">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">Settings</h1>
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* Notifications */}
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3 px-1">
            Notifications
          </h2>
          <Card>
            <CardContent className="p-0 divide-y divide-border">
              <SettingToggle
                icon={<Bell className="h-5 w-5" />}
                title="Push Notifications"
                description="Get instant alerts for bids and updates"
                checked={notifications.push}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, push: checked })
                }
              />
              <SettingToggle
                icon={<Smartphone className="h-5 w-5" />}
                title="SMS Alerts"
                description="Receive text messages for SOS status"
                checked={notifications.sms}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, sms: checked })
                }
              />
              <SettingToggle
                icon={<Bell className="h-5 w-5" />}
                title="Bid Alerts"
                description="Notify when new bids arrive"
                checked={notifications.bidAlerts}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, bidAlerts: checked })
                }
              />
              <SettingToggle
                icon={<Bell className="h-5 w-5" />}
                title="Promotions"
                description="Receive offers and discounts"
                checked={notifications.promotions}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, promotions: checked })
                }
              />
            </CardContent>
          </Card>
        </section>

        {/* Preferences */}
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3 px-1">
            Preferences
          </h2>
          <Card>
            <CardContent className="p-0 divide-y divide-border">
              <SettingToggle
                icon={<Moon className="h-5 w-5" />}
                title="Dark Mode"
                description="Use dark theme"
                checked={preferences.darkMode}
                onCheckedChange={(checked) =>
                  setPreferences({ ...preferences, darkMode: checked })
                }
              />
              <SettingToggle
                icon={<Volume2 className="h-5 w-5" />}
                title="Sound Effects"
                description="Play sounds for notifications"
                checked={preferences.soundEffects}
                onCheckedChange={(checked) =>
                  setPreferences({ ...preferences, soundEffects: checked })
                }
              />
              <SettingToggle
                icon={<Vibrate className="h-5 w-5" />}
                title="Haptic Feedback"
                description="Vibrate on interactions"
                checked={preferences.hapticFeedback}
                onCheckedChange={(checked) =>
                  setPreferences({ ...preferences, hapticFeedback: checked })
                }
              />
              <SettingToggle
                icon={<MapPin className="h-5 w-5" />}
                title="Auto-detect Location"
                description="Automatically use GPS for SOS"
                checked={preferences.autoDetectLocation}
                onCheckedChange={(checked) =>
                  setPreferences({ ...preferences, autoDetectLocation: checked })
                }
              />
              <SettingToggle
                icon={<Eye className="h-5 w-5" />}
                title="Show Trust Scores"
                description="Display provider trust ratings"
                checked={preferences.showTrustScore}
                onCheckedChange={(checked) =>
                  setPreferences({ ...preferences, showTrustScore: checked })
                }
              />
            </CardContent>
          </Card>
        </section>

        {/* Language & Region */}
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3 px-1">
            Language & Region
          </h2>
          <Card>
            <CardContent className="p-0 divide-y divide-border">
              <SettingLink
                icon={<Globe className="h-5 w-5" />}
                title="Language"
                value="English"
              />
              <SettingLink
                icon={<CreditCard className="h-5 w-5" />}
                title="Currency"
                value="GH₵ (Cedis)"
              />
            </CardContent>
          </Card>
        </section>

        {/* Security */}
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3 px-1">
            Security & Privacy
          </h2>
          <Card>
            <CardContent className="p-0 divide-y divide-border">
              <SettingLink
                icon={<Shield className="h-5 w-5" />}
                title="Emergency Contacts"
                value="3 contacts"
                href="/profile"
              />
              <SettingLink
                icon={<Shield className="h-5 w-5" />}
                title="Ride-or-Tow Safety"
                value="Enabled"
                badge="Active"
                badgeVariant="success"
              />
              <SettingLink
                icon={<Shield className="h-5 w-5" />}
                title="Privacy Policy"
              />
              <SettingLink
                icon={<Shield className="h-5 w-5" />}
                title="Terms of Service"
              />
            </CardContent>
          </Card>
        </section>

        {/* Support */}
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3 px-1">
            Support
          </h2>
          <Card>
            <CardContent className="p-0 divide-y divide-border">
              <SettingLink
                icon={<HelpCircle className="h-5 w-5" />}
                title="Help Center"
              />
              <SettingLink
                icon={<HelpCircle className="h-5 w-5" />}
                title="Contact Support"
              />
              <SettingLink
                icon={<HelpCircle className="h-5 w-5" />}
                title="Report a Problem"
              />
            </CardContent>
          </Card>
        </section>

        {/* Logout */}
        <Button variant="destructive" className="w-full">
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>

        <p className="text-center text-xs text-muted-foreground">
          Tireno v1.0.0
        </p>
      </div>
    </main>
  )
}

interface SettingToggleProps {
  icon: React.ReactNode
  title: string
  description?: string
  checked: boolean
  onCheckedChange: (checked: boolean) => void
}

function SettingToggle({
  icon,
  title,
  description,
  checked,
  onCheckedChange,
}: SettingToggleProps) {
  return (
    <div className="flex items-center justify-between p-4">
      <div className="flex items-center gap-3">
        <div className="text-muted-foreground">{icon}</div>
        <div>
          <p className="font-medium">{title}</p>
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  )
}

interface SettingLinkProps {
  icon: React.ReactNode
  title: string
  value?: string
  href?: string
  badge?: string
  badgeVariant?: "default" | "success"
}

function SettingLink({
  icon,
  title,
  value,
  href = "#",
  badge,
  badgeVariant = "default",
}: SettingLinkProps) {
  return (
    <Link href={href}>
      <div className="flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors">
        <div className="flex items-center gap-3">
          <div className="text-muted-foreground">{icon}</div>
          <p className="font-medium">{title}</p>
        </div>
        <div className="flex items-center gap-2">
          {badge && (
            <Badge
              variant="secondary"
              className={
                badgeVariant === "success"
                  ? "bg-green-500/20 text-green-400"
                  : ""
              }
            >
              {badge}
            </Badge>
          )}
          {value && (
            <span className="text-sm text-muted-foreground">{value}</span>
          )}
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
    </Link>
  )
}
