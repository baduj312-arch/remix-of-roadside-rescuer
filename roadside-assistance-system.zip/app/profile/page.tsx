"use client"

import { BottomNav } from "@/components/tireno/bottom-nav"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  ChevronRight, 
  Wallet, 
  Car, 
  Users, 
  MapPin, 
  Settings, 
  HelpCircle,
  LogOut,
  Shield
} from "lucide-react"
import Link from "next/link"

const emergencyContacts = [
  { name: "Mom", phone: "054 XXX XXXX" },
  { name: "Dad", phone: "020 XXX XXXX" },
  { name: "Ama", phone: "027 XXX XXXX" },
]

const savedLocations = [
  { name: "Home", address: "East Legon, Accra" },
  { name: "Work", address: "Airport City, Accra" },
]

export default function ProfilePage() {
  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="px-4 py-6 max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">
                EA
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h1 className="text-xl font-bold">Edward Anyor</h1>
              <p className="text-sm text-muted-foreground">edward@example.com</p>
              <div className="flex items-center gap-2 mt-2">
                <Shield className="h-4 w-4 text-green-500" />
                <span className="text-xs text-green-500">Verified User</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Wallet Card */}
        <Link href="/wallet">
          <Card className="bg-gradient-to-r from-primary to-primary/80">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Wallet className="h-6 w-6 text-primary-foreground" />
                  <div>
                    <p className="text-sm text-primary-foreground/80">Tireno Wallet</p>
                    <p className="text-2xl font-bold text-primary-foreground">GH₵240.00</p>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-primary-foreground" />
              </div>
            </CardContent>
          </Card>
        </Link>

        {/* Vehicle Info */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                <Car className="h-5 w-5 text-muted-foreground" />
                My Vehicle
              </h2>
              <Button variant="ghost" size="sm">Edit</Button>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Make/Model</span>
                <span className="text-sm font-medium">Toyota Corolla 2019</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">License Plate</span>
                <span className="text-sm font-medium">GR-1234-20</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Color</span>
                <span className="text-sm font-medium">Silver</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                Emergency Contacts
              </h2>
              <Badge className="bg-green-500/20 text-green-400">Ride-or-Tow</Badge>
            </div>
            <div className="space-y-3">
              {emergencyContacts.map((contact, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{contact.name}</p>
                    <p className="text-xs text-muted-foreground">{contact.phone}</p>
                  </div>
                  <Button variant="ghost" size="sm">Edit</Button>
                </div>
              ))}
              <Button variant="secondary" size="sm" className="w-full mt-2">
                Add Contact
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Saved Locations */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                Saved Locations
              </h2>
              <Button variant="ghost" size="sm">Add</Button>
            </div>
            <div className="space-y-3">
              {savedLocations.map((location, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{location.name}</p>
                    <p className="text-xs text-muted-foreground">{location.address}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Menu Items */}
        <div className="space-y-2">
          <Link href="/settings">
            <Button variant="ghost" className="w-full justify-start gap-3 h-12">
              <Settings className="h-5 w-5 text-muted-foreground" />
              Settings
              <ChevronRight className="h-4 w-4 ml-auto text-muted-foreground" />
            </Button>
          </Link>
          <Button variant="ghost" className="w-full justify-start gap-3 h-12">
            <HelpCircle className="h-5 w-5 text-muted-foreground" />
            Help & Support
            <ChevronRight className="h-4 w-4 ml-auto text-muted-foreground" />
          </Button>
          <Button variant="ghost" className="w-full justify-start gap-3 h-12 text-destructive">
            <LogOut className="h-5 w-5" />
            Log Out
          </Button>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}
