"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { JobStatusTimeline } from "@/components/tireno/job-status"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowLeft, 
  Phone, 
  MessageCircle, 
  Shield, 
  CreditCard,
  X,
  MapPin,
  Navigation
} from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"

export default function TrackingPage() {
  const router = useRouter()
  const [eta, setEta] = useState(4)
  const [status, setStatus] = useState<"en_route" | "in_progress" | "completed">("en_route")

  // Simulate ETA countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setEta((prev) => {
        if (prev > 1) return prev - 1
        return prev
      })
    }, 30000) // Update every 30 seconds for demo

    return () => clearInterval(interval)
  }, [])

  // Simulate status progression
  useEffect(() => {
    const timer1 = setTimeout(() => setStatus("in_progress"), 10000)
    return () => clearTimeout(timer1)
  }, [])

  const handleCancel = () => {
    if (confirm("Are you sure you want to cancel this job?")) {
      router.push("/")
    }
  }

  return (
    <main className="min-h-screen pb-6">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-lg font-bold">Live Tracking</h1>
              <p className="text-xs text-muted-foreground">JOB#TRN-A7B3X2</p>
            </div>
          </div>
          <Link href="/chat">
            <Button variant="ghost" size="icon">
              <MessageCircle className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Map Area */}
      <div className="relative h-48 bg-card border-b border-border overflow-hidden">
        {/* Grid background */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,107,44,0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,107,44,0.3) 1px, transparent 1px)
            `,
            backgroundSize: '30px 30px'
          }}
        />
        
        {/* Route visualization */}
        <svg className="absolute inset-0 w-full h-full">
          {/* Animated route line */}
          <motion.path
            d="M 60 140 Q 120 100 180 80 Q 240 60 300 50"
            fill="none"
            stroke="#FF6B2C"
            strokeWidth="3"
            strokeDasharray="8 4"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, ease: "easeInOut" }}
          />
          
          {/* Provider marker */}
          <motion.circle
            cx="60"
            cy="140"
            r="8"
            fill="#FF6B2C"
            initial={{ scale: 0 }}
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
          />
          
          {/* User marker */}
          <circle cx="300" cy="50" r="10" fill="#22C55E" />
          <circle cx="300" cy="50" r="5" fill="white" />
        </svg>

        {/* ETA Chip */}
        <div className="absolute bottom-4 right-4">
          <Badge className="bg-primary text-primary-foreground px-3 py-1.5 text-sm">
            ETA {eta} min
          </Badge>
        </div>

        {/* Location labels */}
        <div className="absolute top-4 left-4 flex items-center gap-2">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-xs text-muted-foreground">Provider</span>
        </div>
        <div className="absolute top-4 right-4 flex items-center gap-2">
          <Navigation className="h-4 w-4 text-green-500" />
          <span className="text-xs text-muted-foreground">You</span>
        </div>
      </div>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Provider Mini Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="h-14 w-14">
                  <AvatarFallback className="bg-secondary text-foreground font-semibold text-lg">
                    KA
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-0.5">
                  <Shield className="h-3 w-3 text-white" />
                </div>
              </div>
              <div className="flex-1">
                <h3 className="font-semibold">Kwame Auto Services</h3>
                <p className="text-sm text-primary">
                  {status === "en_route" ? `En Route · ETA ${eta} min` : "Arrived · In Progress"}
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" size="icon" className="rounded-full">
                  <Phone className="h-4 w-4" />
                </Button>
                <Link href="/chat">
                  <Button variant="secondary" size="icon" className="rounded-full">
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Job Status Timeline */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-4">Job Status</h3>
            <JobStatusTimeline currentStatus={status} />
          </CardContent>
        </Card>

        {/* Ride-or-Tow Safety Card */}
        <Card className="bg-green-500/10 border-green-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-green-500/20 rounded-full">
                <Shield className="h-5 w-5 text-green-500" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-green-400">Ride-or-Tow Active</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  3 contacts tracking your location
                </p>
                <div className="flex gap-2 mt-3">
                  {["Mom", "Dad", "Ama"].map((name) => (
                    <Badge key={name} variant="secondary" className="bg-green-500/20 text-green-400">
                      {name}
                    </Badge>
                  ))}
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="mt-3 text-green-400 hover:text-green-300 p-0 h-auto"
                  onClick={() => {
                    navigator.clipboard.writeText(`https://tireno.app/track/TRN-A7B3X2`)
                    alert("Tracker link copied!")
                  }}
                >
                  Share tracker link
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 10-Minute Free Guarantee */}
        <Card className="bg-primary/10 border-primary/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-primary">10-Min Free Guarantee</h3>
                <p className="text-sm text-muted-foreground">
                  No charge if provider arrives late
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-primary">{eta}:00</p>
                <p className="text-xs text-muted-foreground">remaining</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Summary */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CreditCard className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Payment Method</p>
                  <p className="font-medium">MTN MoMo ···· 2847</p>
                </div>
              </div>
              <p className="text-xl font-bold text-primary">GH₵85</p>
            </div>
          </CardContent>
        </Card>

        {/* Cancel Button */}
        <Button
          variant="destructive"
          size="lg"
          className="w-full"
          onClick={handleCancel}
        >
          <X className="h-4 w-4 mr-2" />
          Cancel Job
        </Button>
      </div>
    </main>
  )
}
