"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { TrustScoreBar } from "@/components/tireno/provider-card"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { 
  Home, 
  Briefcase, 
  DollarSign, 
  User,
  MapPin,
  Clock,
  Star,
  TrendingUp,
  Zap,
  AlertCircle
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

const weeklyEarnings = [45, 80, 120, 65, 95, 140, 85]

export default function ProviderDashboardPage() {
  const router = useRouter()
  const [isAvailable, setIsAvailable] = useState(true)
  const [showBidModal, setShowBidModal] = useState(false)

  const stats = {
    todayEarnings: 285,
    todayJobs: 4,
    bidWinRate: 72,
    avgRating: 4.8,
    acceptanceRate: 95,
    avgResponseTime: "45s",
    trustScore: 94,
  }

  const liveRequest = {
    id: "TRN-X4K9M2",
    serviceType: "Mechanic",
    distance: "1.2 km",
    address: "Ring Road Central, Accra",
    issue: "Car won't start",
    urgency: "high",
  }

  return (
    <main className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between px-4 py-3 max-w-md mx-auto">
          <h1 className="text-lg font-bold">Provider Dashboard</h1>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">
              {isAvailable ? "Open" : "Closed"}
            </span>
            <Switch
              checked={isAvailable}
              onCheckedChange={setIsAvailable}
            />
          </div>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Earnings Card */}
        <Card className="bg-gradient-to-br from-primary via-primary to-primary/80 overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-primary-foreground/80">Today&apos;s Earnings</p>
                <p className="text-3xl font-bold text-primary-foreground">
                  GH₵{stats.todayEarnings}
                </p>
                <p className="text-sm text-primary-foreground/80 mt-1">
                  {stats.todayJobs} jobs · 10% platform fee
                </p>
              </div>
              <div className="flex gap-1 items-end h-16">
                {weeklyEarnings.map((value, i) => (
                  <div
                    key={i}
                    className="w-4 bg-primary-foreground/30 rounded-t"
                    style={{ height: `${(value / 150) * 100}%` }}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <TrendingUp className="h-4 w-4" />
                <span className="text-xs">Bid Win Rate</span>
              </div>
              <p className="text-2xl font-bold">{stats.bidWinRate}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Star className="h-4 w-4" />
                <span className="text-xs">Avg Rating</span>
              </div>
              <p className="text-2xl font-bold">{stats.avgRating}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Zap className="h-4 w-4" />
                <span className="text-xs">Acceptance Rate</span>
              </div>
              <p className="text-2xl font-bold">{stats.acceptanceRate}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Clock className="h-4 w-4" />
                <span className="text-xs">Avg Response</span>
              </div>
              <p className="text-2xl font-bold">{stats.avgResponseTime}</p>
            </CardContent>
          </Card>
        </div>

        {/* Live SOS Requests */}
        {isAvailable && (
          <section>
            <h2 className="font-semibold mb-3 flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
              </span>
              Live SOS Requests
            </h2>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="border-primary bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <Badge className="bg-primary text-primary-foreground">
                      {liveRequest.serviceType}
                    </Badge>
                    <Badge variant="secondary" className="bg-red-500/20 text-red-400">
                      Urgent
                    </Badge>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{liveRequest.distance} away</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{liveRequest.address}</p>
                    <p className="text-sm">&quot;{liveRequest.issue}&quot;</p>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      className="flex-1"
                      onClick={() => router.push("/provider-bid")}
                    >
                      Place Bid
                    </Button>
                    <Button variant="secondary">Skip</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </section>
        )}

        {!isAvailable && (
          <Card className="bg-yellow-500/10 border-yellow-500/30">
            <CardContent className="p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0" />
              <div>
                <p className="font-medium text-yellow-400">You&apos;re offline</p>
                <p className="text-sm text-muted-foreground">
                  Turn on availability to receive SOS requests
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Trust Score */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-4">Trust Score</h3>
            <TrustScoreBar 
              score={stats.trustScore} 
              showBreakdown={true}
              rating={stats.avgRating}
              successRate={stats.acceptanceRate}
              responseTime={88}
            />
            <p className="text-xs text-muted-foreground mt-3">
              Higher trust score = more SOS bid opportunities. Updated weekly.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Provider Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-lg">
        <div className="flex items-center justify-around py-2 px-4 max-w-md mx-auto">
          {[
            { href: "/provider-dashboard", icon: Home, label: "Dashboard", active: true },
            { href: "/provider-jobs", icon: Briefcase, label: "Jobs", active: false },
            { href: "/provider-earnings", icon: DollarSign, label: "Earnings", active: false },
            { href: "/provider-profile", icon: User, label: "Profile", active: false },
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors",
                item.active
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </main>
  )
}
