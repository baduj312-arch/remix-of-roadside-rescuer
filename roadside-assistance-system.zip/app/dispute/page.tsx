"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Upload, MessageCircle, FileText, Clock, CheckCircle } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

const issueCategories = [
  "Overcharged",
  "Incomplete repair",
  "No-show",
  "Unprofessional behavior",
  "Damage to vehicle",
  "Other",
]

export default function DisputePage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [category, setCategory] = useState("")
  const [description, setDescription] = useState("")
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([])
  const [caseId] = useState(`DIS-${Math.random().toString(36).substring(2, 8).toUpperCase()}`)

  const progress = (step / 3) * 100

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1)
    }
  }

  const handleFileUpload = () => {
    // Simulate file upload
    const newFile = `evidence_${uploadedFiles.length + 1}.jpg`
    setUploadedFiles([...uploadedFiles, newFile])
  }

  return (
    <main className="min-h-screen pb-6">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          <Link href="/history">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-bold">File a Dispute</h1>
            <p className="text-xs text-muted-foreground">Step {step} of 3</p>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="px-4 py-4 max-w-md mx-auto">
        <Progress value={progress} className="h-2" />
      </div>

      <div className="px-4 pb-6 max-w-md mx-auto space-y-6">
        {/* Step 1: Issue Details */}
        {step === 1 && (
          <>
            <h2 className="text-xl font-semibold">What went wrong?</h2>
            
            {/* Job Reference */}
            <Card className="bg-secondary/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">JOB#TRN-A7B3X2</p>
                    <p className="text-sm text-muted-foreground">Kwame Auto Services · May 18, 2026</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Category */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Issue Category</label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="bg-card">
                  <SelectValue placeholder="Select an issue type" />
                </SelectTrigger>
                <SelectContent>
                  {issueCategories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Describe the Issue</label>
              <Textarea
                placeholder="Please provide details about what happened..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={5}
                className="bg-card"
              />
            </div>

            <Button 
              size="lg" 
              className="w-full"
              onClick={handleNext}
              disabled={!category || !description}
            >
              Next
            </Button>
          </>
        )}

        {/* Step 2: Upload Evidence */}
        {step === 2 && (
          <>
            <h2 className="text-xl font-semibold">Upload Evidence</h2>
            
            {/* Upload Area */}
            <div
              onClick={handleFileUpload}
              className={cn(
                "border-2 border-dashed border-border rounded-xl p-8",
                "flex flex-col items-center justify-center gap-3",
                "cursor-pointer hover:border-primary/50 transition-colors"
              )}
            >
              <Upload className="h-10 w-10 text-muted-foreground" />
              <p className="text-sm text-muted-foreground text-center">
                Click to upload photos or videos<br />
                Max 5 files, 10MB each
              </p>
            </div>

            {/* Uploaded Files */}
            {uploadedFiles.length > 0 && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Uploaded Files</label>
                <div className="grid grid-cols-2 gap-2">
                  {uploadedFiles.map((file, index) => (
                    <Card key={index}>
                      <CardContent className="p-3 flex items-center gap-2">
                        <div className="h-10 w-10 bg-secondary rounded flex items-center justify-center">
                          <FileText className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <span className="text-sm truncate">{file}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Chat Log */}
            <Card className="bg-green-500/10 border-green-500/30">
              <CardContent className="p-4 flex items-center gap-3">
                <MessageCircle className="h-5 w-5 text-green-500" />
                <div>
                  <p className="font-medium text-green-400">Chat Log Auto-Attached</p>
                  <p className="text-sm text-muted-foreground">Your conversation history is included</p>
                </div>
              </CardContent>
            </Card>

            <Button 
              size="lg" 
              className="w-full"
              onClick={handleNext}
            >
              Submit Dispute
            </Button>
          </>
        )}

        {/* Step 3: Confirmation */}
        {step === 3 && (
          <div className="text-center space-y-6 py-8">
            <div className="flex justify-center">
              <div className="p-4 bg-green-500/20 rounded-full">
                <CheckCircle className="h-12 w-12 text-green-500" />
              </div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-xl font-semibold">Dispute Submitted</h2>
              <p className="text-muted-foreground">Case ID: {caseId}</p>
            </div>

            <Card className="bg-blue-500/10 border-blue-500/30">
              <CardContent className="p-4 text-left">
                <p className="text-sm text-blue-400 font-medium mb-2">
                  Mediator assigned - 24h review
                </p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Provider has 24 hours to respond
                  </li>
                  <li className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Mediator will review within 48 hours
                  </li>
                  <li className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Refund processed in 3-5 business days if approved
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Button 
              size="lg" 
              className="w-full"
              onClick={() => router.push("/")}
            >
              Back to Home
            </Button>
          </div>
        )}
      </div>
    </main>
  )
}
