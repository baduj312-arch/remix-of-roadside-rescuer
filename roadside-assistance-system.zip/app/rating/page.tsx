"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Star, PartyPopper } from "lucide-react"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

const categoryRatings = [
  { key: "speed", label: "Speed" },
  { key: "price", label: "Price Fairness" },
  { key: "professionalism", label: "Professionalism" },
]

export default function RatingPage() {
  const router = useRouter()
  const [overallRating, setOverallRating] = useState(0)
  const [categoryScores, setCategoryScores] = useState<Record<string, number>>({
    speed: 0,
    price: 0,
    professionalism: 0,
  })
  const [review, setReview] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleCategoryRating = (category: string, rating: number) => {
    setCategoryScores((prev) => ({ ...prev, [category]: rating }))
  }

  const handleSubmit = () => {
    setIsSubmitting(true)
    setTimeout(() => {
      router.push("/")
    }, 1000)
  }

  const handleSkip = () => {
    router.push("/")
  }

  return (
    <main className="min-h-screen pb-6">
      <div className="px-4 py-8 max-w-md mx-auto space-y-6">
        {/* Success Header */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center space-y-2"
        >
          <div className="flex justify-center">
            <div className="p-4 bg-green-500/20 rounded-full">
              <PartyPopper className="h-12 w-12 text-green-500" />
            </div>
          </div>
          <h1 className="text-2xl font-bold">Job Complete!</h1>
          <p className="text-muted-foreground">Payment of GH₵85.00 confirmed</p>
        </motion.div>

        {/* Provider Info */}
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="bg-secondary text-foreground font-semibold text-xl">
                KA
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-lg">Kwame Auto Services</h3>
              <p className="text-sm text-muted-foreground">Mechanic Service</p>
            </div>
          </CardContent>
        </Card>

        {/* Overall Rating */}
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">How was your experience?</p>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <motion.button
                key={star}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setOverallRating(star)}
                className="p-1"
              >
                <Star
                  className={cn(
                    "h-10 w-10 transition-colors",
                    star <= overallRating
                      ? "fill-yellow-500 text-yellow-500"
                      : "text-muted-foreground"
                  )}
                />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Category Ratings */}
        <Card>
          <CardContent className="p-4 space-y-4">
            {categoryRatings.map((category) => (
              <div key={category.key} className="flex items-center justify-between">
                <span className="text-sm font-medium">{category.label}</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => handleCategoryRating(category.key, star)}
                      className="p-0.5"
                    >
                      <Star
                        className={cn(
                          "h-5 w-5 transition-colors",
                          star <= categoryScores[category.key]
                            ? "fill-yellow-500 text-yellow-500"
                            : "text-muted-foreground"
                        )}
                      />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Written Review */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Write a review (optional)</label>
          <Textarea
            placeholder="Share your experience..."
            value={review}
            onChange={(e) => setReview(e.target.value)}
            rows={4}
            className="bg-card"
          />
        </div>

        {/* Submit Button */}
        <Button
          size="lg"
          className="w-full h-14 text-lg font-semibold"
          onClick={handleSubmit}
          disabled={overallRating === 0 || isSubmitting}
        >
          {isSubmitting ? "Submitting..." : "Submit Review"}
        </Button>

        {/* Skip Button */}
        <Button
          variant="ghost"
          className="w-full"
          onClick={handleSkip}
        >
          Skip for now
        </Button>
      </div>
    </main>
  )
}
