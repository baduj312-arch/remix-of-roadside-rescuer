"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowLeft, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Plus, 
  Minus,
  CreditCard,
  Shield
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

const transactions = [
  { id: "1", type: "credit", description: "Wallet Top Up", date: "May 18, 2026", amount: 100 },
  { id: "2", type: "debit", description: "Payment to Kwame Auto", date: "May 18, 2026", amount: 85 },
  { id: "3", type: "credit", description: "Refund - Job Cancelled", date: "May 15, 2026", amount: 50 },
  { id: "4", type: "debit", description: "Payment to Speed Towing", date: "May 12, 2026", amount: 150 },
  { id: "5", type: "credit", description: "Wallet Top Up", date: "May 10, 2026", amount: 200 },
]

const quickAmounts = [50, 100, 200, 500]

const linkedAccounts = [
  { id: "1", type: "MTN MoMo", number: "···· 2847", primary: true },
  { id: "2", type: "Visa Card", number: "···· 4532", primary: false },
]

export default function WalletPage() {
  const [balance] = useState(240)
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null)
  const [customAmount, setCustomAmount] = useState("")

  return (
    <main className="min-h-screen pb-6">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          <Link href="/profile">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-lg font-bold">Tireno Wallet</h1>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Balance Card */}
        <Card className="bg-gradient-to-br from-primary via-primary to-primary/80 overflow-hidden">
          <CardContent className="p-6">
            <div className="text-center space-y-2">
              <p className="text-sm text-primary-foreground/80">Available Balance</p>
              <p className="text-4xl font-bold text-primary-foreground">GH₵{balance.toFixed(2)}</p>
              <p className="text-sm text-primary-foreground/80">Edward Anyor</p>
            </div>
            <div className="flex justify-center gap-4 mt-6">
              <Button variant="secondary" size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Top Up
              </Button>
              <Button variant="secondary" size="sm" className="gap-2">
                <Minus className="h-4 w-4" />
                Withdraw
              </Button>
              <Button variant="secondary" size="sm" className="gap-2">
                <ArrowUpRight className="h-4 w-4" />
                Send
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="transactions" className="w-full">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="topup">Top Up</TabsTrigger>
            <TabsTrigger value="linked">Linked</TabsTrigger>
          </TabsList>

          {/* Transactions Tab */}
          <TabsContent value="transactions" className="mt-4">
            <div className="space-y-3">
              {transactions.map((tx) => (
                <Card key={tx.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "p-2 rounded-full",
                        tx.type === "credit" ? "bg-green-500/20" : "bg-red-500/20"
                      )}>
                        {tx.type === "credit" ? (
                          <ArrowDownLeft className="h-4 w-4 text-green-500" />
                        ) : (
                          <ArrowUpRight className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">{tx.date}</p>
                      </div>
                      <span className={cn(
                        "font-semibold",
                        tx.type === "credit" ? "text-green-500" : "text-red-500"
                      )}>
                        {tx.type === "credit" ? "+" : "-"}GH₵{tx.amount}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Top Up Tab */}
          <TabsContent value="topup" className="mt-4 space-y-4">
            <div className="grid grid-cols-4 gap-2">
              {quickAmounts.map((amount) => (
                <Button
                  key={amount}
                  variant={selectedAmount === amount ? "default" : "secondary"}
                  onClick={() => {
                    setSelectedAmount(amount)
                    setCustomAmount("")
                  }}
                >
                  GH₵{amount}
                </Button>
              ))}
            </div>

            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Custom Amount</label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={customAmount}
                onChange={(e) => {
                  setCustomAmount(e.target.value)
                  setSelectedAmount(null)
                }}
                className="bg-card"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Payment Method</label>
              <Card className="border-primary">
                <CardContent className="p-4 flex items-center gap-3">
                  <CreditCard className="h-5 w-5 text-muted-foreground" />
                  <div className="flex-1">
                    <p className="font-medium">MTN MoMo</p>
                    <p className="text-xs text-muted-foreground">···· 2847</p>
                  </div>
                  <Badge>Primary</Badge>
                </CardContent>
              </Card>
            </div>

            <Button 
              size="lg" 
              className="w-full"
              disabled={!selectedAmount && !customAmount}
            >
              Top Up GH₵{selectedAmount || customAmount || "0"}
            </Button>
          </TabsContent>

          {/* Linked Accounts Tab */}
          <TabsContent value="linked" className="mt-4 space-y-4">
            <div className="space-y-3">
              {linkedAccounts.map((account) => (
                <Card key={account.id} className={account.primary ? "border-primary" : ""}>
                  <CardContent className="p-4 flex items-center gap-4">
                    <CreditCard className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1">
                      <p className="font-medium">{account.type}</p>
                      <p className="text-xs text-muted-foreground">{account.number}</p>
                    </div>
                    {account.primary && <Badge>Primary</Badge>}
                  </CardContent>
                </Card>
              ))}

              <Button variant="outline" className="w-full border-dashed gap-2">
                <Plus className="h-4 w-4" />
                Link New Account
              </Button>
            </div>

            <Card className="bg-blue-500/10 border-blue-500/30">
              <CardContent className="p-4 flex items-start gap-3">
                <Shield className="h-5 w-5 text-blue-500 shrink-0" />
                <p className="text-sm text-blue-400">
                  Your payment information is encrypted and securely stored. We never share your financial details with providers.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
