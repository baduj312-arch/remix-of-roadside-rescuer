"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Wrench, Info, Lock } from "lucide-react"
import Link from "next/link"

const paymentMethods = [
  { id: "momo", label: "MTN MoMo", sublabel: "···· 2847", icon: "📱" },
  { id: "visa", label: "Visa Card", sublabel: "···· 4532", icon: "💳" },
  { id: "cod", label: "Cash on Delivery", sublabel: "Pay provider directly", icon: "💵" },
  { id: "wallet", label: "Tireno Wallet", sublabel: "Balance: GH₵240.00", icon: "👛" },
]

export default function PaymentPage() {
  const router = useRouter()
  const [selectedMethod, setSelectedMethod] = useState("momo")
  const [isProcessing, setIsProcessing] = useState(false)

  const handlePayment = () => {
    setIsProcessing(true)
    setTimeout(() => {
      router.push("/rating")
    }, 1500)
  }

  const baseService = 70
  const distanceFee = 8
  const platformFee = baseService * 0.1
  const total = baseService + distanceFee + platformFee

  return (
    <main className="min-h-screen pb-6">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center gap-4 px-4 py-3 max-w-md mx-auto">
          <Link href="/tracking">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-bold">Payment</h1>
            <p className="text-xs text-muted-foreground">Complete your payment</p>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Receipt Card */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4 pb-4 border-b border-border">
              <div className="p-3 bg-primary/20 rounded-full">
                <Wrench className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold">Kwame Auto Services</h3>
                <p className="text-sm text-muted-foreground">JOB#TRN-A7B3X2</p>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Base Service</span>
                <span>GH₵{baseService.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Distance Fee (2.4 km)</span>
                <span>GH₵{distanceFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Platform Fee (10%)</span>
                <span>GH₵{platformFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-3 border-t border-border">
                <span className="font-semibold">Total</span>
                <span className="text-xl font-bold text-primary">GH₵{total.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Methods */}
        <div>
          <h2 className="font-semibold mb-3">Payment Method</h2>
          <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod}>
            <div className="space-y-3">
              {paymentMethods.map((method) => (
                <Card
                  key={method.id}
                  className={selectedMethod === method.id ? "border-primary" : ""}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <RadioGroupItem value={method.id} id={method.id} />
                      <span className="text-2xl">{method.icon}</span>
                      <Label htmlFor={method.id} className="flex-1 cursor-pointer">
                        <p className="font-medium">{method.label}</p>
                        <p className="text-sm text-muted-foreground">{method.sublabel}</p>
                      </Label>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </RadioGroup>
        </div>

        {/* Escrow Info */}
        <Card className="bg-blue-500/10 border-blue-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
              <p className="text-sm text-blue-400">
                Payment is held in escrow and will only be released to the provider once you confirm the job is complete.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Pay Button */}
        <Button
          size="lg"
          className="w-full h-14 text-lg font-semibold"
          onClick={handlePayment}
          disabled={isProcessing}
        >
          <Lock className="h-4 w-4 mr-2" />
          {isProcessing ? "Processing..." : `Pay GH₵${total.toFixed(2)} Securely`}
        </Button>

        <p className="text-center text-xs text-muted-foreground">
          Secured by 256-bit SSL encryption
        </p>
      </div>
    </main>
  )
}
