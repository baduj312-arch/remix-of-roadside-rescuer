# Tireno Integration Guide

Complete guide for integrating production services into the Tireno platform.

## Database Setup

### Option 1: Supabase (Recommended)

1. **Create Supabase Project**
   - Visit [supabase.com](https://supabase.com)
   - Create new project
   - Copy connection string

2. **Install Client**
   ```bash
   pnpm add @supabase/supabase-js
   ```

3. **Create Database Schema**

   ```sql
   -- Users Table
   CREATE TABLE users (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     phone VARCHAR(20) UNIQUE NOT NULL,
     email VARCHAR(255) UNIQUE,
     name VARCHAR(255) NOT NULL,
     type VARCHAR(20) NOT NULL, -- 'driver', 'provider', 'admin'
     wallet DECIMAL(10, 2) DEFAULT 0,
     trust_score INT DEFAULT 0,
     verified BOOLEAN DEFAULT FALSE,
     created_at TIMESTAMP DEFAULT NOW(),
     updated_at TIMESTAMP DEFAULT NOW()
   );

   -- SOS Requests Table
   CREATE TABLE sos_requests (
     id VARCHAR(20) PRIMARY KEY,
     driver_id UUID NOT NULL REFERENCES users(id),
     service_type VARCHAR(50) NOT NULL,
     latitude DECIMAL(10, 8) NOT NULL,
     longitude DECIMAL(11, 8) NOT NULL,
     description TEXT,
     vehicle_info TEXT,
     status VARCHAR(50) DEFAULT 'broadcasting',
     created_at TIMESTAMP DEFAULT NOW(),
     expires_at TIMESTAMP,
     accepted_at TIMESTAMP,
     completed_at TIMESTAMP
   );

   -- Bids Table
   CREATE TABLE bids (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     sos_id VARCHAR(20) NOT NULL REFERENCES sos_requests(id),
     provider_id UUID NOT NULL REFERENCES users(id),
     amount DECIMAL(8, 2) NOT NULL,
     eta INT NOT NULL,
     special_notes TEXT,
     status VARCHAR(50) DEFAULT 'pending',
     created_at TIMESTAMP DEFAULT NOW(),
     accepted_at TIMESTAMP
   );

   -- Payments Table
   CREATE TABLE payments (
     id VARCHAR(30) PRIMARY KEY,
     job_id VARCHAR(20) NOT NULL,
     driver_id UUID NOT NULL REFERENCES users(id),
     provider_id UUID NOT NULL REFERENCES users(id),
     amount DECIMAL(8, 2) NOT NULL,
     method VARCHAR(20) NOT NULL,
     status VARCHAR(50) DEFAULT 'completed',
     transaction_id VARCHAR(100),
     created_at TIMESTAMP DEFAULT NOW(),
     completed_at TIMESTAMP
   );

   -- Ratings Table
   CREATE TABLE ratings (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     job_id VARCHAR(20) NOT NULL,
     driver_id UUID NOT NULL REFERENCES users(id),
     provider_id UUID NOT NULL REFERENCES users(id),
     overall_rating INT NOT NULL,
     punctuality INT,
     quality INT,
     communication INT,
     review TEXT,
     created_at TIMESTAMP DEFAULT NOW()
   );

   -- Notifications Table
   CREATE TABLE notifications (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     user_id UUID NOT NULL REFERENCES users(id),
     type VARCHAR(50) NOT NULL,
     title VARCHAR(255) NOT NULL,
     message TEXT NOT NULL,
     read BOOLEAN DEFAULT FALSE,
     data JSONB,
     created_at TIMESTAMP DEFAULT NOW()
   );

   -- Create indexes
   CREATE INDEX idx_users_phone ON users(phone);
   CREATE INDEX idx_users_email ON users(email);
   CREATE INDEX idx_sos_driver ON sos_requests(driver_id);
   CREATE INDEX idx_bids_sos ON bids(sos_id);
   CREATE INDEX idx_bids_provider ON bids(provider_id);
   CREATE INDEX idx_payments_job ON payments(job_id);
   CREATE INDEX idx_ratings_job ON ratings(job_id);
   CREATE INDEX idx_notifications_user ON notifications(user_id);
   ```

4. **Add Environment Variables**
   ```env
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   SUPABASE_SERVICE_KEY=your_supabase_service_key
   ```

5. **Create Supabase Client Hook**
   ```typescript
   // hooks/useSupabase.ts
   import { createClient } from '@supabase/supabase-js'

   const supabase = createClient(
     process.env.NEXT_PUBLIC_SUPABASE_URL!,
     process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
   )

   export function useSupabase() {
     return supabase
   }
   ```

### Option 2: Neon PostgreSQL

1. **Create Neon Project**
   - Visit [neon.tech](https://neon.tech)
   - Create new project
   - Copy connection string

2. **Install Adapter**
   ```bash
   pnpm add @neondatabase/serverless
   ```

3. **Use Same Schema as Supabase**

4. **Add Environment Variables**
   ```env
   DATABASE_URL=postgresql://user:password@host/database
   ```

### Option 3: Firebase

1. **Create Firebase Project**
   ```bash
   pnpm add firebase
   ```

2. **Initialize in App**
   ```typescript
   import { initializeApp } from 'firebase/app'
   import { getFirestore } from 'firebase/firestore'

   const firebaseConfig = {
     // Your config
   }

   const app = initializeApp(firebaseConfig)
   export const db = getFirestore(app)
   ```

## Authentication Setup

### Option 1: Supabase Auth (Recommended)

```typescript
// lib/auth.ts
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export async function signUpWithPhone(phone: string, password: string) {
  const { data, error } = await supabase.auth.signUpWithPassword({
    email: `${phone}@tireno.app`, // Use phone as unique identifier
    password,
    options: {
      data: { phone }
    }
  })
  return { data, error }
}

export async function signInWithPhone(phone: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: `${phone}@tireno.app`,
    password,
  })
  return { data, error }
}
```

### Option 2: Auth.js v5

```bash
pnpm add next-auth@latest
```

```typescript
// auth.config.ts
import { NextAuthConfig } from "next-auth"
import Credentials from "next-auth/providers/credentials"

export const authConfig = {
  providers: [
    Credentials({
      async authorize(credentials) {
        // Verify phone and password against database
        // Hash password with bcrypt
      },
    }),
  ],
} satisfies NextAuthConfig
```

### Option 3: Clerk

```bash
pnpm add @clerk/nextjs
```

```typescript
// lib/clerk-middleware.ts
import { clerkMiddleware } from '@clerk/nextjs/server'

export default clerkMiddleware()
```

## Payment Gateway Integration

### Stripe Setup

1. **Install Stripe**
   ```bash
   pnpm add stripe @stripe/stripe-js
   ```

2. **Create Webhook Endpoint**
   ```typescript
   // app/api/webhooks/stripe/route.ts
   import Stripe from 'stripe'

   const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

   export async function POST(request: Request) {
     const sig = request.headers.get('stripe-signature')!
     const body = await request.text()

     try {
       const event = stripe.webhooks.constructEvent(
         body,
         sig,
         process.env.STRIPE_WEBHOOK_SECRET!
       )

       switch (event.type) {
         case 'payment_intent.succeeded':
           // Handle successful payment
           break
       }
       return new Response('OK')
     } catch (error) {
       return new Response('Webhook Error', { status: 400 })
     }
   }
   ```

3. **Add Environment Variables**
   ```env
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_xxx
   STRIPE_SECRET_KEY=sk_xxx
   STRIPE_WEBHOOK_SECRET=whsec_xxx
   ```

### Mobile Money (MTN/Airtel Ghana)

1. **Use Flutterwave for Mobile Money**
   ```bash
   pnpm add flutterwave-node-v3
   ```

2. **Implement Payment**
   ```typescript
   // lib/flutterwave.ts
   import Flutterwave from 'flutterwave-node-v3'

   const flutterwave = new Flutterwave(
     process.env.NEXT_PUBLIC_FLUTTERWAVE_KEY!,
     process.env.FLUTTERWAVE_SECRET_KEY!
   )

   export async function processMobileMoneyPayment(
     amount: number,
     phone: string,
     jobId: string
   ) {
     const payload = {
       amount,
       phone_number: phone,
       currency: 'GHS',
       tx_ref: jobId,
       description: `Tireno Service Payment - ${jobId}`,
       redirect_url: `${process.env.NEXT_PUBLIC_APP_URL}/payment/confirm`,
     }

     return flutterwave.MobileMoney.ghana(payload)
   }
   ```

## SMS Notifications

### Twilio Setup

```bash
pnpm add twilio
```

```typescript
// lib/sms.ts
import twilio from 'twilio'

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
)

export async function sendSMS(to: string, message: string) {
  return client.messages.create({
    body: message,
    from: process.env.TWILIO_PHONE_NUMBER,
    to,
  })
}

// Example usage
export async function notifyProvider(
  phone: string,
  sosId: string,
  serviceType: string
) {
  await sendSMS(
    phone,
    `New SOS request [${sosId}] for ${serviceType} service. Check app for details.`
  )
}
```

## Email Notifications

### SendGrid Setup

```bash
pnpm add @sendgrid/mail
```

```typescript
// lib/email.ts
import sgMail from '@sendgrid/mail'

sgMail.setApiKey(process.env.SENDGRID_API_KEY!)

export async function sendEmail(
  to: string,
  subject: string,
  html: string
) {
  return sgMail.send({
    to,
    from: process.env.SENDGRID_FROM_EMAIL!,
    subject,
    html,
  })
}

// Example: Payment receipt
export async function sendPaymentReceipt(
  email: string,
  jobId: string,
  amount: number,
  provider: string
) {
  const html = `
    <h2>Payment Confirmation</h2>
    <p>Job ID: ${jobId}</p>
    <p>Provider: ${provider}</p>
    <p>Amount: GH₵${amount.toFixed(2)}</p>
  `

  return sendEmail(email, 'Payment Receipt - Tireno', html)
}
```

## Push Notifications

### Firebase Cloud Messaging

```bash
pnpm add firebase-admin
```

```typescript
// lib/push-notifications.ts
import * as admin from 'firebase-admin'

admin.initializeApp({
  credential: admin.credential.cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_PRIVATE_KEY,
  }),
})

export async function sendPushNotification(
  deviceToken: string,
  title: string,
  body: string,
  data?: Record<string, string>
) {
  return admin.messaging().send({
    notification: { title, body },
    data,
    token: deviceToken,
  })
}

// Example: New bid notification
export async function notifyDriverNewBid(
  deviceToken: string,
  providerName: string,
  amount: number
) {
  await sendPushNotification(
    deviceToken,
    'New Bid Received',
    `${providerName} bid GH₵${amount}`,
    {
      type: 'bid',
      action: 'open_bidding',
    }
  )
}
```

## Real-Time Updates (WebSocket)

### Using Socket.io

```bash
pnpm add socket.io socket.io-client
```

```typescript
// app/api/socket/route.ts
import { createServer } from 'http'
import { Server } from 'socket.io'

export async function GET(req: Request) {
  // Socket.io initialization handled by Next.js socket plugin
  // Events: 'sos:new', 'bid:received', 'location:update', 'chat:message'
}
```

## Environment Variables Template

Create `.env.local`:

```env
# Database
DATABASE_URL=postgresql://...
NEXT_PUBLIC_SUPABASE_URL=https://...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_KEY=...

# Authentication
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_secret_key
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_...
CLERK_SECRET_KEY=sk_...

# Payments
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_...
STRIPE_SECRET_KEY=sk_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_FLUTTERWAVE_KEY=FLWPUBK_...
FLUTTERWAVE_SECRET_KEY=FLWSECK_...

# SMS
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_PHONE_NUMBER=+1234567890

# Email
SENDGRID_API_KEY=SG...
SENDGRID_FROM_EMAIL=noreply@tireno.app

# Push Notifications
FIREBASE_PROJECT_ID=...
FIREBASE_CLIENT_EMAIL=...
FIREBASE_PRIVATE_KEY=...

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Testing Integrations

### Database
```typescript
// hooks/useTestDB.ts
export function useTestDB() {
  const testConnection = async () => {
    const response = await fetch('/api/health')
    return response.ok
  }

  const seedData = async () => {
    // Insert test data
  }

  return { testConnection, seedData }
}
```

### Payments
```typescript
// lib/test-payments.ts
export const TEST_CARDS = {
  success: '4242 4242 4242 4242',
  failure: '4000 0000 0000 0002',
  declined: '4000 0000 0000 0069',
}
```

## Deployment Checklist

- [ ] Database migration scripts running
- [ ] Environment variables configured
- [ ] Authentication enabled
- [ ] Payment webhooks configured
- [ ] SMS notifications tested
- [ ] Email templates created
- [ ] Push notifications registered
- [ ] Rate limiting enabled
- [ ] Error tracking (Sentry) configured
- [ ] Monitoring & analytics setup
- [ ] Backup strategy defined
- [ ] Security headers configured
- [ ] CORS properly configured
- [ ] SSL certificates valid
- [ ] CDN configured for assets

## Support

For integration help:
1. Check integration-specific documentation
2. Review environment variable setup
3. Test API endpoints with Postman
4. Check server logs for errors
5. Verify webhook delivery in provider dashboard
