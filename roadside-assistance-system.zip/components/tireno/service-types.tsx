"use client"

import { cn } from "@/lib/utils"
import { 
  Wrench, 
  Car, 
  Fuel, 
  Key, 
  Zap, 
  CircleDot,
  type LucideIcon 
} from "lucide-react"

export type ServiceType = 
  | "mechanic" 
  | "tow" 
  | "fuel" 
  | "locksmith" 
  | "battery" 
  | "tire"

interface ServiceTypeInfo {
  icon: LucideIcon
  label: string
  description: string
}

export const serviceTypes: Record<ServiceType, ServiceTypeInfo> = {
  mechanic: {
    icon: Wrench,
    label: "Mechanic",
    description: "Engine, brakes, general repairs",
  },
  tow: {
    icon: Car,
    label: "Tow Truck",
    description: "Vehicle towing & recovery",
  },
  fuel: {
    icon: Fuel,
    label: "Fuel Delivery",
    description: "Emergency fuel delivery",
  },
  locksmith: {
    icon: Key,
    label: "Locksmith",
    description: "Keys locked in car",
  },
  battery: {
    icon: Zap,
    label: "Battery",
    description: "Jump start & replacement",
  },
  tire: {
    icon: CircleDot,
    label: "Vulcanizer",
    description: "Flat tire repair & change",
  },
}

interface ServiceCardProps {
  type: ServiceType
  selected?: boolean
  onClick?: () => void
  compact?: boolean
}

export function ServiceCard({ type, selected, onClick, compact }: ServiceCardProps) {
  const service = serviceTypes[type]
  const Icon = service.icon

  if (compact) {
    return (
      <button
        onClick={onClick}
        className={cn(
          "flex flex-col items-center gap-2 p-4 rounded-xl transition-all",
          "bg-secondary hover:bg-secondary/80",
          selected && "ring-2 ring-primary bg-primary/10"
        )}
      >
        <div className={cn(
          "p-3 rounded-full",
          selected ? "bg-primary text-primary-foreground" : "bg-muted"
        )}>
          <Icon className="h-5 w-5" />
        </div>
        <span className="text-xs font-medium">{service.label}</span>
      </button>
    )
  }

  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-4 p-4 rounded-xl transition-all w-full text-left",
        "bg-card border border-border hover:border-primary/50",
        selected && "ring-2 ring-primary border-primary"
      )}
    >
      <div className={cn(
        "p-3 rounded-full shrink-0",
        selected ? "bg-primary text-primary-foreground" : "bg-secondary"
      )}>
        <Icon className="h-6 w-6" />
      </div>
      <div className="min-w-0">
        <p className="font-semibold">{service.label}</p>
        <p className="text-sm text-muted-foreground truncate">{service.description}</p>
      </div>
    </button>
  )
}

interface ServiceGridProps {
  selected?: ServiceType
  onSelect?: (type: ServiceType) => void
}

export function ServiceGrid({ selected, onSelect }: ServiceGridProps) {
  return (
    <div className="grid grid-cols-3 gap-3">
      {(Object.keys(serviceTypes) as ServiceType[]).map((type) => (
        <ServiceCard
          key={type}
          type={type}
          selected={selected === type}
          onClick={() => onSelect?.(type)}
          compact
        />
      ))}
    </div>
  )
}
