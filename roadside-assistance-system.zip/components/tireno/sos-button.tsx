"use client"

import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import Link from "next/link"

interface SOSButtonProps {
  size?: "sm" | "md" | "lg"
  className?: string
}

export function SOSButton({ size = "lg", className }: SOSButtonProps) {
  const sizeClasses = {
    sm: "h-16 w-16 text-lg",
    md: "h-24 w-24 text-xl",
    lg: "h-32 w-32 text-2xl",
  }

  return (
    <Link href="/sos" className={cn("relative inline-flex", className)}>
      {/* Pulsing rings */}
      <span className="absolute inset-0 rounded-full bg-primary/30 animate-pulse-ring" />
      <span 
        className="absolute inset-0 rounded-full bg-primary/20 animate-pulse-ring" 
        style={{ animationDelay: "0.5s" }} 
      />
      
      {/* Main button */}
      <motion.span
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={cn(
          "relative flex items-center justify-center rounded-full",
          "bg-primary text-primary-foreground font-bold shadow-lg",
          "shadow-primary/50 cursor-pointer",
          sizeClasses[size]
        )}
      >
        SOS
      </motion.span>
    </Link>
  )
}
