"use client"

import { cn } from "@/lib/utils"
import { Star, Shield, Phone, MessageCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export interface Provider {
  id: string
  name: string
  initials: string
  rating: number
  reviewCount: number
  trustScore: number
  verified: boolean
  serviceType: string
  distance?: string
  eta?: string
  price?: number
  successRate?: number
  jobsToday?: number
  isOnline?: boolean
}

interface ProviderCardProps {
  provider: Provider
  variant?: "compact" | "detailed" | "bid"
  onAccept?: () => void
  onCall?: () => void
  onChat?: () => void
  showBestValue?: boolean
}

export function ProviderCard({
  provider,
  variant = "compact",
  onAccept,
  onCall,
  onChat,
  showBestValue,
}: ProviderCardProps) {
  return (
    <div
      className={cn(
        "relative bg-card border border-border rounded-xl p-4 transition-all",
        "hover:border-primary/50"
      )}
    >
      {showBestValue && (
        <Badge className="absolute -top-2 right-4 bg-primary text-primary-foreground">
          Best Value
        </Badge>
      )}

      <div className="flex items-start gap-3">
        <div className="relative">
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-secondary text-foreground font-semibold">
              {provider.initials}
            </AvatarFallback>
          </Avatar>
          {provider.verified && (
            <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-0.5">
              <Shield className="h-3 w-3 text-white" />
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold truncate">{provider.name}</h3>
            {provider.isOnline && (
              <span className="h-2 w-2 rounded-full bg-green-500" />
            )}
          </div>
          
          <div className="flex items-center gap-2 mt-1">
            <div className="flex items-center gap-1">
              <Star className="h-3.5 w-3.5 fill-yellow-500 text-yellow-500" />
              <span className="text-sm font-medium">{provider.rating.toFixed(1)}</span>
              <span className="text-xs text-muted-foreground">
                ({provider.reviewCount})
              </span>
            </div>
            {provider.distance && (
              <span className="text-xs text-muted-foreground">
                {provider.distance}
              </span>
            )}
          </div>

          {variant !== "compact" && (
            <div className="mt-2">
              <TrustScoreBar score={provider.trustScore} />
            </div>
          )}

          {variant === "bid" && (
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {provider.eta && (
                <Badge variant="secondary" className="bg-primary/20 text-primary">
                  ETA {provider.eta}
                </Badge>
              )}
              {provider.successRate && (
                <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                  {provider.successRate}% success
                </Badge>
              )}
              {provider.jobsToday !== undefined && (
                <Badge variant="secondary">
                  {provider.jobsToday} jobs today
                </Badge>
              )}
            </div>
          )}
        </div>

        {provider.price && (
          <div className="text-right shrink-0">
            <p className="text-xl font-bold text-primary">
              GH₵{provider.price}
            </p>
          </div>
        )}
      </div>

      {(onCall || onChat || onAccept) && (
        <div className="flex items-center gap-2 mt-4">
          {onCall && (
            <Button
              size="icon"
              variant="secondary"
              onClick={onCall}
              className="rounded-full"
            >
              <Phone className="h-4 w-4" />
            </Button>
          )}
          {onChat && (
            <Button
              size="icon"
              variant="secondary"
              onClick={onChat}
              className="rounded-full"
            >
              <MessageCircle className="h-4 w-4" />
            </Button>
          )}
          {onAccept && (
            <Button onClick={onAccept} className="flex-1">
              Accept Bid
            </Button>
          )}
        </div>
      )}
    </div>
  )
}

interface TrustScoreBarProps {
  score: number
  showLabel?: boolean
  showBreakdown?: boolean
  rating?: number
  successRate?: number
  responseTime?: number
}

export function TrustScoreBar({ 
  score, 
  showLabel = true, 
  showBreakdown = false,
  rating = 4.5,
  successRate = 92,
  responseTime = 88
}: TrustScoreBarProps) {
  const getColor = () => {
    if (score >= 90) return "bg-green-500"
    if (score >= 70) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        {showLabel && (
          <span className="text-xs text-muted-foreground">Trust</span>
        )}
        <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className={cn("h-full rounded-full transition-all", getColor())}
            style={{ width: `${score}%` }}
          />
        </div>
        <span className="text-xs font-medium">{score}/100</span>
      </div>
      
      {showBreakdown && (
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="text-center p-2 bg-secondary/50 rounded">
            <p className="text-muted-foreground">Rating</p>
            <p className="font-medium">{rating}/5</p>
            <p className="text-[10px] text-muted-foreground">50%</p>
          </div>
          <div className="text-center p-2 bg-secondary/50 rounded">
            <p className="text-muted-foreground">Success</p>
            <p className="font-medium">{successRate}%</p>
            <p className="text-[10px] text-muted-foreground">30%</p>
          </div>
          <div className="text-center p-2 bg-secondary/50 rounded">
            <p className="text-muted-foreground">Response</p>
            <p className="font-medium">{responseTime}%</p>
            <p className="text-[10px] text-muted-foreground">20%</p>
          </div>
        </div>
      )}
    </div>
  )
}
