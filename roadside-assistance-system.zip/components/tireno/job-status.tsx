"use client"

import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

export type JobStatus = 
  | "request_sent" 
  | "provider_assigned" 
  | "en_route" 
  | "in_progress" 
  | "completed"

interface JobStatusTimelineProps {
  currentStatus: JobStatus
  className?: string
}

const statusSteps: { key: JobStatus; label: string }[] = [
  { key: "request_sent", label: "Request Sent" },
  { key: "provider_assigned", label: "Provider Assigned" },
  { key: "en_route", label: "En Route" },
  { key: "in_progress", label: "In Progress" },
  { key: "completed", label: "Completed" },
]

export function JobStatusTimeline({ currentStatus, className }: JobStatusTimelineProps) {
  const currentIndex = statusSteps.findIndex((s) => s.key === currentStatus)

  return (
    <div className={cn("space-y-2", className)}>
      {statusSteps.map((step, index) => {
        const isCompleted = index < currentIndex
        const isActive = index === currentIndex
        const isPending = index > currentIndex

        return (
          <div key={step.key} className="flex items-center gap-3">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  "h-8 w-8 rounded-full flex items-center justify-center transition-all",
                  isCompleted && "bg-green-500 text-white",
                  isActive && "bg-primary text-primary-foreground animate-pulse",
                  isPending && "bg-secondary text-muted-foreground"
                )}
              >
                {isCompleted ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <span className="text-xs font-medium">{index + 1}</span>
                )}
              </div>
              {index < statusSteps.length - 1 && (
                <div
                  className={cn(
                    "w-0.5 h-4 mt-1",
                    index < currentIndex ? "bg-green-500" : "bg-secondary"
                  )}
                />
              )}
            </div>
            <span
              className={cn(
                "text-sm font-medium",
                isCompleted && "text-green-500",
                isActive && "text-primary",
                isPending && "text-muted-foreground"
              )}
            >
              {step.label}
            </span>
          </div>
        )
      })}
    </div>
  )
}

interface JobStatusBadgeProps {
  status: JobStatus
}

export function JobStatusBadge({ status }: JobStatusBadgeProps) {
  const statusConfig: Record<JobStatus, { label: string; className: string }> = {
    request_sent: { label: "Pending", className: "bg-yellow-500/20 text-yellow-400" },
    provider_assigned: { label: "Assigned", className: "bg-blue-500/20 text-blue-400" },
    en_route: { label: "En Route", className: "bg-primary/20 text-primary" },
    in_progress: { label: "In Progress", className: "bg-primary/20 text-primary" },
    completed: { label: "Completed", className: "bg-green-500/20 text-green-400" },
  }

  const config = statusConfig[status]

  return (
    <span className={cn("px-2 py-1 rounded-full text-xs font-medium", config.className)}>
      {config.label}
    </span>
  )
}
