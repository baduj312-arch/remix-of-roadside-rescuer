import { useState, useCallback } from 'react'

interface APIResponse<T = any> {
  success?: boolean
  error?: string
  data?: T
}

interface UseAPIOptions {
  onSuccess?: (data: any) => void
  onError?: (error: string) => void
}

export function useAPI() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const request = useCallback(
    async <T,>(
      endpoint: string,
      method: 'GET' | 'POST' | 'PATCH' | 'DELETE' = 'GET',
      body?: any,
      options?: UseAPIOptions
    ): Promise<T | null> => {
      setLoading(true)
      setError(null)

      try {
        const response = await fetch(endpoint, {
          method,
          headers: {
            'Content-Type': 'application/json',
          },
          body: body ? JSON.stringify(body) : undefined,
        })

        if (!response.ok) {
          const errorData = await response.json()
          const errorMessage = errorData.error || 'Request failed'
          setError(errorMessage)
          options?.onError?.(errorMessage)
          return null
        }

        const data = await response.json()
        setLoading(false)
        options?.onSuccess?.(data)
        return data as T
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Network error'
        setError(errorMessage)
        options?.onError?.(errorMessage)
        setLoading(false)
        return null
      }
    },
    []
  )

  return { request, loading, error }
}

// Specialized hooks for common operations
export function useSOS() {
  const { request, loading, error } = useAPI()

  const createSOS = useCallback(
    async (sosData: {
      serviceType: string
      latitude: number
      longitude: number
      description?: string
      vehicleInfo?: string
    }) => {
      return request(
        '/api/sos',
        'POST',
        sosData
      )
    },
    [request]
  )

  return { createSOS, loading, error }
}

export function useBids() {
  const { request, loading, error } = useAPI()

  const submitBid = useCallback(
    async (bidData: {
      sosId: string
      providerId: string
      amount: number
      eta: number
      specialNotes?: string
    }) => {
      return request(
        '/api/bids',
        'POST',
        bidData
      )
    },
    [request]
  )

  const getBids = useCallback(
    async (sosId: string) => {
      return request(`/api/bids?sosId=${sosId}`, 'GET')
    },
    [request]
  )

  return { submitBid, getBids, loading, error }
}

export function usePayments() {
  const { request, loading, error } = useAPI()

  const processPayment = useCallback(
    async (paymentData: {
      jobId: string
      amount: number
      method: 'momo' | 'visa' | 'cash' | 'wallet'
      providerId?: string
      driverId?: string
    }) => {
      return request(
        '/api/payments',
        'POST',
        paymentData
      )
    },
    [request]
  )

  return { processPayment, loading, error }
}

export function useNotifications() {
  const { request, loading, error } = useAPI()

  const getNotifications = useCallback(
    async (userId: string, unreadOnly = false) => {
      return request(
        `/api/notifications?userId=${userId}&unreadOnly=${unreadOnly}`,
        'GET'
      )
    },
    [request]
  )

  const markAsRead = useCallback(
    async (userId: string, notificationId: string) => {
      return request(
        '/api/notifications',
        'PATCH',
        { userId, notificationId, read: true }
      )
    },
    [request]
  )

  return { getNotifications, markAsRead, loading, error }
}
