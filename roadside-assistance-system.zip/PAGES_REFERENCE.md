# Tireno Pages Reference Guide

Complete guide to all pages in the Tireno system with URLs, features, and user flows.

## Driver Pages

### 1. Home Dashboard `/`
**Purpose**: Main entry point for drivers
**Features**:
- Emergency SOS button (large red button)
- Service type grid (mechanic, towing, vulcanizer, battery, fuel, locksmith)
- Nearby providers list (ranked by trust score)
- Quick links to register/join as provider
- Access to all major features
- Ride-or-Tow safety banner
- Fake Mechanic Shield awareness banner
- Bottom navigation

**User Flow**: 
- Tap SOS button → `/sos`
- Tap service type → `/sos`
- Tap provider card → `/provider/[id]`
- Tap history icon → `/history`
- Tap wallet icon → `/wallet`
- Tap profile icon → `/profile`

---

### 2. SOS Request `/sos`
**Purpose**: Create emergency assistance request
**Features**:
- Service type selection (6 categories)
- GPS location auto-detect with manual override
- Vehicle information input
- Emergency contact alerts
- Submit and confirm flow
- Job ID generation (TRN-XXXXXX)
- Status broadcasting indicator

**Form Fields**:
- Service Type (required)
- Current Location (auto-detect)
- Vehicle Make/Model/Year
- Additional Notes
- Emergency Contact Notification

**Next Step**: Auto-redirect to `/bidding` with SOS ID

---

### 3. Live Bidding `/bidding`
**Purpose**: Receive and accept provider bids in real-time
**Features**:
- 3-minute countdown timer (180 seconds)
- Real-time bid animation
- Provider cards with:
  - Profile photo/initials
  - Name and rating
  - Trust score with color coding
  - Estimated time of arrival (ETA)
  - Quoted price in GH₵
  - Success rate percentage
  - Verification badge
- Automatic best bid highlighting
- "Accept Best Bid" button
- Waiting state with skeleton loaders

**Best Bid Factors** (in order):
1. Highest trust score
2. Lowest price
3. Fastest ETA

**Bid Countdown Stages**:
- 180s: Normal
- 60s: Yellow warning
- 10s: Red urgent

**Next Step**: Tap "Accept" → `/tracking?provider=[id]`

---

### 4. Live Tracking `/tracking`
**Purpose**: Monitor job progress from acceptance to completion
**Features**:
- Visual route map placeholder
- Job status timeline:
  - "Provider Accepted"
  - "En Route"
  - "Arrived"
  - "Service In Progress"
  - "Service Completed"
- Provider details card:
  - Name and photo
  - Rating and trust score
  - Phone number
  - Vehicle info
  - Current location
- Ride-or-Tow safety card:
  - Contact list
  - Share tracker link button
  - Real-time tracking
- 10-Minute Free Guarantee countdown
- In-app chat access
- Payment summary preview
- Job ID and timer

**Chat Access**: "Message Provider" button → `/chat`

**Payment Trigger**: When status reaches "Service Completed" → `/payment`

---

### 5. In-App Chat `/chat`
**Purpose**: Direct communication with provider
**Features**:
- Real-time message exchange
- Provider info header
- Quick reply buttons:
  - "I'm here"
  - "How long?"
  - "Something wrong"
  - "Emergency alert"
- Message history
- Typing indicators (placeholder)
- Timestamp for each message
- Read receipts (planned)

**Quick Replies** auto-populate common messages

**Back to Tracking**: Header back button

---

### 6. Payment `/payment`
**Purpose**: Secure payment processing
**Features**:
- Service summary:
  - Service type
  - Provider name
  - Date and time
  - Duration
- Itemized breakdown:
  - Service charge
  - Taxes (if applicable)
  - Discount (if applicable)
  - Total amount
- Payment method selection:
  - Mobile Money (MTN/Airtel)
  - Debit/Credit Card (Visa/Mastercard)
  - Pay at Location (Cash)
  - Tireno Wallet
- Escrow information
- Invoice/Receipt generation
- Payment confirmation status
- Tip option
- Dispute option link

**Payment Flow**:
1. Select payment method
2. Enter payment details
3. Confirm amount
4. Process payment
5. Show receipt

**Next Step**: 
- Payment success → `/rating`
- Dispute → `/dispute`

---

### 7. Rating & Review `/rating`
**Purpose**: Provide feedback on completed service
**Features**:
- Overall 5-star rating
- Category ratings:
  - Punctuality (1-5 stars)
  - Service Quality (1-5 stars)
  - Communication (1-5 stars)
- Written review text area
- Photo upload (planned)
- Anonymous option
- Submit and thank you screen
- Provider's response handling (if available)

**Rating Submission**:
- Saves to provider's profile
- Updates trust score calculation
- Triggers thank you notification to provider

**Next Steps**:
- View history → `/history`
- Back to home → `/`

---

### 8. Profile `/profile`
**Purpose**: Manage user account and information
**Features**:
- Profile header:
  - User photo
  - Name
  - Phone number
  - Wallet balance
  - Trust/Safety score
- Personal Information:
  - Full name
  - Phone number
  - Email address
  - Home address
- Emergency Contacts:
  - List of contacts
  - Add/edit/delete
  - Relationship field
- Vehicles:
  - Make, model, year
  - Color
  - License plate
  - VIN
  - Insurance info
- Saved Locations:
  - Home
  - Work
  - Other frequent locations
- Menu Items:
  - Settings → `/settings`
  - Help & Support
  - Log Out

**Edit Functionality**: Each section is editable

**Next Steps**:
- Settings → `/settings`
- Back to home → `/`

---

### 9. Providers Directory `/providers`
**Purpose**: Browse and search available service providers
**Features**:
- Service type filter:
  - All services
  - Mechanic
  - Vulcanizer
  - Towing
  - Battery
  - Fuel delivery
  - Locksmith
- Location sort:
  - Nearest
  - Highest rated
  - Lowest price
- Provider cards showing:
  - Photo/initials
  - Name
  - Rating and reviews
  - Trust score
  - Service type badge
  - ETA
  - Price range
  - Verification badge
- View detailed profile button

**Provider Sorting**:
1. By proximity
2. By trust score
3. By price (lowest first)

**Tap Provider** → `/provider/[id]`

---

### 10. Provider Profile `/provider/[id]`
**Purpose**: Detailed provider information before booking
**Tabs**:
1. **Overview**:
   - Profile photo
   - Name and service type
   - Rating and reviews count
   - Trust score with breakdown
   - About section
   - Location
   - Response time
   - Specialties list
   - Verification badges

2. **Reviews**:
   - Rating summary (5-star breakdown)
   - Individual reviews with:
     - Reviewer name
     - Rating
     - Date
     - Review text
     - Service type

3. **Pricing**:
   - Service rates
   - Typical costs
   - Additional charges
   - Payment methods accepted

**Trust Score Display**:
- Overall score
- Rating (0-5 normalized)
- Success rate (%)
- Response time score

**Action Button**: "Request This Provider" → `/sos` with provider preference

---

### 11. Job History `/history`
**Purpose**: View past completed jobs
**Features**:
- List of completed jobs with:
  - Job ID
  - Service type
  - Provider name
  - Date and time
  - Amount paid
  - Your rating (if rated)
  - Review summary
- Filter options:
  - All
  - Completed
  - Cancelled
  - Disputed
- Sort options:
  - Recent first
  - Oldest first
  - Price (high to low)
- Summary statistics:
  - Total jobs completed
  - Total amount spent
  - Average rating given
  - Most used service type

**Job Details**: Tap job → show full details and review

**Re-request**: "Request Similar Service" button

---

### 12. Wallet `/wallet`
**Purpose**: Manage account balance and transactions
**Features**:
- Wallet balance display (large, prominent)
- Account status:
  - Available balance
  - Pending transfers
  - Wallet ID
- Recent transactions list:
  - Date
  - Description
  - Amount (income/expense)
  - Method
  - Status
- Transaction types:
  - Top-ups
  - Payments
  - Refunds
  - Transfers
- Transaction filters:
  - All
  - Top-ups
  - Payments
  - Refunds
- Top-up options:
  - Mobile Money
  - Debit/Credit Card
  - Bank transfer
  - Promo codes
- Linked accounts:
  - Bank account
  - Mobile Money numbers
  - Add/remove accounts

**Top-up Flow**: Tap "Top-up" → select method → enter amount → confirm

---

### 13. Notifications `/notifications`
**Purpose**: Notification center with filtering
**Features**:
- Tab navigation:
  - All
  - Unread
  - SOS updates
  - Payments
  - Messages
  - Ratings
  - System
- Notification cards:
  - Type icon
  - Title
  - Message
  - Timestamp
  - Read indicator
- Mark as read/unread
- Mark all as read
- Delete notification
- Archive (planned)

**Notification Types**:
- **Bid**: New provider bid received
- **SOS**: Job status updates
- **Payment**: Transaction confirmations
- **Message**: Chat messages
- **Rating**: Review feedback
- **System**: Platform announcements

**Tap Notification**:
- Bid notification → `/bidding`
- SOS update → `/tracking`
- Payment → `/payment`
- Message → `/chat`
- Rating → View on profile

---

### 14. Settings `/settings`
**Purpose**: User preferences and account settings
**Sections**:

1. **Notifications**:
   - Push notifications toggle
   - SMS notifications toggle
   - Email notifications toggle
   - Bid alerts toggle
   - Promotional emails toggle
   - Quiet hours setting

2. **App Preferences**:
   - Dark mode (already enabled)
   - Sound effects toggle
   - Haptic feedback toggle
   - Auto-detect location toggle
   - Language selection
   - Currency (GHS)

3. **Security & Privacy**:
   - Change password
   - Two-factor authentication
   - Session management
   - Privacy policy link
   - Data export
   - Delete account option

4. **Support**:
   - FAQ link
   - Contact us link
   - Report issue
   - Give feedback
   - Version info

**Changes**: Auto-save or explicit save

---

### 15. Dispute Resolution `/dispute`
**Purpose**: File and track disputes
**Features**:
- Dispute wizard (3 steps):
  1. **Select Job**: Choose past job to dispute
  2. **Reason**: Select reason category
     - Service not completed
     - Charged wrong amount
     - Quality issues
     - Safety concern
     - Other
  3. **Evidence**: Add photos/description
- Evidence upload:
  - Photo upload
  - Text description
  - Receipt attachment
- Dispute details:
  - Job ID
  - Provider name
  - Original amount
  - Claimed refund amount
  - Reason category
  - Evidence
- Submission confirmation
- Dispute tracking:
  - Dispute ID
  - Status (Pending/Investigating/Resolved)
  - Messages from support team
  - Resolution details
  - Refund status

**Status Tracking**: View status and messages

---

## Provider Pages

### 16. Provider Registration `/provider-register`
**Purpose**: Onboard new service providers
**Features**:
- 4-step registration wizard:

1. **Personal Information**:
   - Full name
   - Phone number (primary)
   - Email
   - ID type (National ID, Passport, etc.)
   - ID number
   - Date of birth
   - Photo upload

2. **Business Information**:
   - Business name
   - Business registration number
   - Business type (sole proprietor, LLC, etc.)
   - Years of experience
   - Service specialties
   - Service area

3. **Service Details**:
   - Service types (select multiple)
   - Price ranges for each service
   - Available hours
   - Emergency availability (24/7)
   - Service radius (in km)
   - Accept terms & conditions

4. **Verification**:
   - Fake Mechanic Shield verification
   - Upload documents:
     - Government ID
     - Business license
     - Reference letters
   - Verification status tracking
   - Payment account setup:
     - Bank account
     - Mobile Money number
     - Wallet preferences

**Progress Indicator**: Step tracker (1/4, 2/4, etc.)

**Save Draft**: Option to save and continue later

**Submission**: Final review and submit

**Post-Registration**: Pending verification notice

---

### 17. Provider Dashboard `/provider-dashboard`
**Purpose**: Manage provider business and performance
**Features**:
- Navigation tabs:
  1. Overview
  2. Active Jobs
  3. Earnings
  4. Ratings

**Tab 1: Overview**:
- KPI cards:
  - Today's earnings
  - Jobs completed (this month)
  - Trust score (with breakdown)
  - Next payout amount
- Quick actions:
  - "View Active Requests" button
  - "Start Shift" / "End Shift"
  - "Update Availability"
- Performance chart (monthly earnings)
- Trust score breakdown:
  - Overall score
  - Rating component (0-5)
  - Success rate (%)
  - Response time score
  - Comparison to top providers

**Tab 2: Active Jobs**:
- Current active requests:
  - SOS ID
  - Service type
  - Location/distance
  - Estimated value
  - Accept button
  - Skip button
- Job timer (showing how long request is open)
- Notification: New SOS received

**Tab 3: Earnings**:
- Monthly earnings graph
- Transaction list:
  - Job details
  - Amount earned
  - Completion date
  - Rating received
- Filter by date range
- Commission breakdown:
  - Gross amount
  - Commission paid
  - Amount received
- Payout management:
  - Pending payout
  - Scheduled payouts
  - Bank details
  - Request payout

**Tab 4: Ratings**:
- Rating summary:
  - Average rating (0-5)
  - Total ratings received
  - 5-star count
  - 4-star count
  - 3-star count
  - 2-star count
  - 1-star count
- Recent reviews:
  - Reviewer name
  - Rating
  - Date
  - Review text
  - Your response (if replied)
  - Reply form

**Header**:
- Profile photo
- Provider name
- Trust score badge
- Status indicator (Online/Offline/Busy)
- Toggle availability
- Access settings/help

---

## Admin Pages

### 18. Admin Dashboard `/admin`
**Purpose**: System administration and monitoring
**Access**: PIN-protected (1234)
**PIN Verification**: First access or after session timeout

**Features** (5 main tabs):

**Tab 1: Overview**:
- Real-time statistics:
  - Active SOS requests (with map)
  - Total users (drivers + providers)
  - Session active count
  - Total revenue (today/month/all-time)
- KPI cards:
  - Average response time
  - SOS completion rate
  - Provider acceptance rate
  - Fraud incidents
- Charts:
  - Revenue trend (daily/weekly/monthly)
  - User growth
  - SOS request volume
  - Peak hours heatmap

**Tab 2: Providers**:
- Provider verification queue:
  - New providers awaiting verification
  - Name, service type, trust score
  - Approve/Reject buttons
  - Verification document review
- Fraud alerts:
  - Suspicious patterns
  - Multiple rejections
  - Chargeback reports
  - Review and action buttons
- Provider list:
  - All registered providers
  - Filter by status (verified, pending, suspended)
  - Search by name
  - Sort by trust score, earnings, ratings
  - Take action menu:
    - View profile
    - Send message
    - Suspend account
    - Review documents

**Tab 3: Finance**:
- Revenue dashboard:
  - Total revenue
  - Commission earned
  - Payouts made
  - Pending payouts
- Charts:
  - Revenue by service type
  - Revenue by region
  - Commission breakdown
- Payout management:
  - Scheduled payouts
  - Failed payouts
  - Retry failed transfers
  - Generate reports
- Transaction logs:
  - All transactions
  - Filter by type
  - Search by job ID / provider
  - Export to CSV

**Tab 4: Analytics**:
- User analytics:
  - New users (daily/weekly/monthly)
  - Active users
  - Returning users
  - User retention rate
- Service analytics:
  - Requests by service type
  - Completion rates
  - Average job value
  - Popular time slots
- Regional analytics:
  - Requests by region
  - Revenue by region
  - Provider density
  - User density
- Custom reports:
  - Date range selection
  - Metric selection
  - Generate and export

**Tab 5: Broadcasts**:
- System announcements:
  - Create new broadcast
  - Title and message
  - Type (info, warning, urgent)
  - Target audience (all users, drivers, providers)
  - Schedule send (immediate/scheduled)
- Sent broadcasts history:
  - Show/hide status
  - Recipients count
  - Send time
  - Click-through rate
  - Edit/resend option
- Maintenance mode:
  - Enable/disable
  - Maintenance message
  - Schedule window
  - Notify users toggle

**Admin Menu**:
- Profile
- Settings
- Help
- Log out

---

## Navigation Structure

### Bottom Navigation Bar (All Driver Pages)
```
Home | SOS | Providers | History | Profile
 🏠   🆘    👷          📋       👤
```

**Active State**: Current page highlighted with orange accent

---

## URL Routing Summary

```
Driver Pages:
  /                    Home Dashboard
  /sos                 SOS Request
  /bidding             Live Bidding (POST from SOS)
  /tracking            Live Tracking (POST from Bidding)
  /chat                In-App Chat
  /payment             Payment Processing
  /rating              Rating & Review
  /profile             User Profile
  /providers           Provider Directory
  /provider/[id]       Provider Details
  /history             Job History
  /wallet              Wallet Management
  /notifications       Notification Center
  /settings            User Settings
  /dispute             Dispute Resolution

Provider Pages:
  /provider-register   Registration (4-step)
  /provider-dashboard  Analytics & Management

Admin Pages:
  /admin               Dashboard (PIN: 1234)

API Routes:
  /api/sos             SOS operations
  /api/bids            Bidding operations
  /api/payments        Payment operations
  /api/notifications   Notification operations
```

---

## Feature Access by User Type

### Driver
- Home Dashboard ✅
- SOS Request ✅
- Live Bidding ✅
- Live Tracking ✅
- Chat ✅
- Payment ✅
- Rating ✅
- Profile ✅
- Providers ✅
- History ✅
- Wallet ✅
- Notifications ✅
- Settings ✅
- Dispute ✅
- Admin ❌

### Provider
- Home Dashboard (limited) ⚠️
- SOS Requests (view & bid) ✅
- Dashboard ✅
- Profile ✅
- Chat ✅
- Earnings ✅
- Ratings ✅
- Settings ✅
- Admin ❌

### Admin
- All Driver Pages (view) 📋
- All Provider Pages (view) 📋
- Admin Dashboard ✅
- Provider Verification ✅
- System Broadcasts ✅
- Analytics & Reports ✅

---

## State Management Across Pages

### SOS Flow State
```
SOS Page (form) 
  → Submit SOS
  → Redirect to Bidding with sosId
  → Accept Bid with providerId
  → Redirect to Tracking with provider & sosId
  → Complete Service
  → Redirect to Payment with jobId
  → Process Payment
  → Redirect to Rating with providerId & jobId
```

### Page Data Retention
- Local State: Form inputs, UI toggles
- URL Params: Job IDs, provider IDs, service types
- Session Storage: Auth tokens, preferences
- Local Storage: Saved locations, recent searches

---

## Mobile Responsiveness

### Viewport Widths Tested
- 375px (iPhone SE)
- 390px (iPhone 12)
- 430px (iPhone 14 Pro Max)
- 768px (iPad Mini)

### Touch Targets
- Minimum 44x44px for all interactive elements
- 48px recommended for buttons
- 16px minimum padding around interactive areas

### Landscape Mode
- All pages support landscape viewing
- Navigation adapts for wider screens
- Content scales appropriately

---

## Performance Metrics

### Page Load Times
- Home: ~1.2s
- SOS: ~0.8s
- Bidding: ~1.5s
- Tracking: ~2.0s
- Profile: ~1.0s

### Interaction Speed
- Page transitions: <200ms
- Button feedback: <100ms
- Form validation: <50ms
- Notification display: <100ms

---

This reference guide provides complete information for understanding the user interface, navigation flows, and feature sets across the entire Tireno system.
