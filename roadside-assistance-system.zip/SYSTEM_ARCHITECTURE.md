# Tireno Roadside Assistance System - Architecture & Documentation

## System Overview

Tireno is a comprehensive mobile-first roadside assistance platform connecting drivers with mechanics, vulcanizers, tow truck operators, and emergency services in real-time. The system prioritizes safety, trust, and transparent pricing.

## Tech Stack

- **Framework**: Next.js 16 (App Router)
- **UI Components**: shadcn/ui with Radix UI primitives
- **Styling**: Tailwind CSS v4
- **Animations**: Framer Motion
- **Forms**: React Hook Form + Zod
- **Type Safety**: TypeScript

## Project Structure

```
/app                          # Next.js App Router pages
  /api                        # API routes
    /sos                      # SOS request endpoints
    /bids                     # Bidding system endpoints
    /payments                 # Payment processing
    /notifications            # Notification management
  /admin                      # Admin dashboard
  /bidding                    # Live bidding interface
  /chat                       # In-app messaging
  /dispute                    # Dispute resolution
  /history                    # Job history
  /notifications              # Notification center
  /payment                    # Payment screen
  /profile                    # User profile
  /provider                   # Provider details
  /provider-dashboard         # Provider management
  /provider-register          # Provider onboarding
  /providers                  # Provider search
  /rating                     # Rating & reviews
  /settings                   # User settings
  /sos                        # SOS request creation
  /tracking                   # Live job tracking
  /wallet                     # Wallet management

/components                   # Reusable components
  /ui                         # Base UI components (shadcn/ui)
  /tireno                     # Domain-specific components
    /bottom-nav.tsx           # Navigation bar
    /provider-card.tsx        # Provider display cards
    /job-status.tsx           # Job status tracker
    /service-types.tsx        # Service selection grid
    /sos-button.tsx           # Emergency SOS button

/hooks                        # Custom React hooks
  /useAPI.ts                  # API request management

/lib                          # Utility functions & constants
  /trust-score.ts             # Trust score calculations
  /constants.ts               # System-wide constants
  /utils.ts                   # Helper functions

/styles                       # Global styles
  /globals.css                # Tailwind + CSS variables

/public                       # Static assets
```

## Core Features

### 1. SOS Request System (`/sos`)
- Instant service type selection (6 categories)
- GPS-based location detection
- Real-time broadcast to nearby providers
- Vehicle information capture
- Emergency contact notifications

**API**: `POST /api/sos`

### 2. Live Bidding System (`/bidding`)
- 3-minute countdown timer
- Real-time bid reception animation
- Provider ranking by trust score
- Instant bid acceptance
- Automatic SOS to tracking transition

**API**: `GET|POST /api/bids`

### 3. Live Tracking (`/tracking`)
- Visual route map (placeholder)
- Job status timeline
- Provider real-time info
- Ride-or-Tow safety tracker sharing
- 10-minute free guarantee display
- In-app chat access

### 4. Payment Processing (`/payment`)
- Itemized service breakdown
- Multiple payment methods (MoMo, Visa, Cash, Wallet)
- Escrow protection
- Receipt generation
- Dispute options

**API**: `GET|POST /api/payments`

### 5. Rating & Review System (`/rating`)
- 5-star overall rating
- Category ratings (punctuality, quality, communication)
- Written reviews with photos
- Provider response handling

### 6. Provider Management
- **Registration** (`/provider-register`): 4-step onboarding
  - Personal verification
  - Business registration
  - Service selection
  - Fake Mechanic Shield verification
  
- **Dashboard** (`/provider-dashboard`): Performance metrics
  - Earnings & payouts
  - Live SOS requests
  - Trust score breakdown
  - Job statistics
  - Rating analytics

### 7. Admin Dashboard (`/admin`)
PIN Protected (1234)

**Tabs**:
- **Overview**: KPIs, revenue, response times, active requests
- **Providers**: Verification queue, fraud detection, trust scores
- **Finance**: Commission tracking, payouts, revenue by region
- **Analytics**: Peak hours, user growth, service demand
- **Broadcast**: System-wide alerts and announcements

**API**: Real-time data aggregation

### 8. User Features
- **Profile** (`/profile`): Personal info, emergency contacts, vehicle details
- **History** (`/history`): Past jobs, ratings received, lifetime statistics
- **Wallet** (`/wallet`): Balance management, transaction history, top-ups
- **Notifications** (`/notifications`): Filtered notification center
- **Settings** (`/settings`): Preferences, privacy, language, notifications
- **Providers** (`/providers`): Browse and search nearby providers
- **Disputes** (`/dispute`): 3-step dispute filing with evidence upload

## Trust Score System

### Algorithm
```
Trust Score = (Rating × 0.5) + (Success Rate × 0.3) + (Response Time × 0.2)
```

### Components
1. **Rating (50%)**: Average customer rating (0-5 scale normalized to 0-100)
2. **Success Rate (30%)**: Percentage of completed vs. total jobs
3. **Response Time (20%)**: Average response time to SOS requests

### Tiers
- **Platinum**: 95+ (5% commission)
- **Gold**: 90-94 (10% commission)
- **Silver**: 80-89
- **Bronze**: 70-79
- **Standard**: 60-69
- **New Provider**: <60

## Safety Features

### Ride-or-Tow Safety Module
- Multi-contact location sharing
- Shareable tracker links
- Real-time GPS tracking
- Emergency contact alerts
- Session recording capability

### Fake Mechanic Shield
- Multi-step provider verification:
  1. Government ID verification
  2. Business license validation
  3. Reference checks
  4. Service quality certification
  5. Continuous monitoring

### Escrow Protection
- Payment held until service completion
- Driver satisfaction confirmation
- Automatic release after 24 hours
- Dispute resolution integration

## Real-Time Features

### WebSocket Considerations (Future)
- Live bid updates
- Typing indicators in chat
- Provider location tracking
- Status synchronization

### API Polling (Current)
- BID countdown refresh every 1 second
- Notifications refresh every 30 seconds
- Tracking updates every 5 seconds

## Payment Integration

### Supported Methods
1. **Mobile Money**: MTN, Airtel Ghana
2. **Card Payments**: Visa, Mastercard (Stripe integration ready)
3. **Cash Payment**: Pay at location with invoice
4. **Wallet**: In-app balance management

### Commission Structure
- Standard Providers: 15%
- Premium Providers: 10%
- Platinum Providers: 5%

## Notification System

### Types
- **Bid**: New provider bids received
- **SOS**: Job status updates
- **Payment**: Transaction confirmations
- **Message**: Chat messages
- **Rating**: Feedback received
- **System**: Platform announcements

**API**: `GET|POST|PATCH /api/notifications`

## Data Models

### User
```typescript
interface User {
  id: string
  name: string
  phone: string
  email: string
  type: 'driver' | 'provider' | 'admin'
  wallet: number
  trustScore?: number
  createdAt: Date
}
```

### SOS Request
```typescript
interface SOSRequest {
  id: string
  driverId: string
  serviceType: string
  location: { lat: number; lng: number }
  status: 'broadcasting' | 'accepted' | 'completed'
  createdAt: Date
  expiresAt: Date
}
```

### Bid
```typescript
interface Bid {
  id: string
  sosId: string
  providerId: string
  amount: number
  eta: number
  status: 'pending' | 'accepted' | 'rejected'
  createdAt: Date
}
```

## Performance Considerations

### Mobile Optimization
- Page preloading for critical flows
- Image optimization with Next.js Image
- CSS-in-JS minimization
- Code splitting by route

### Caching Strategy
- Static pages: ISR (Incremental Static Regeneration)
- Dynamic data: Client-side SWR with fallbacks
- API responses: 30-60 second cache headers

## Security

### Input Validation
- Zod schemas for all API inputs
- XSS prevention via React escaping
- CSRF token handling (when auth added)

### Authentication (Future)
- Email/phone verification
- JWT tokens with refresh rotation
- Device fingerprinting
- Rate limiting on API endpoints

### Data Protection
- Encrypted payment data storage
- PII masking in logs
- GDPR compliance ready
- Right to deletion support

## Testing Strategy

### Unit Tests (TODO)
- Trust score calculations
- Payment processing logic
- Validation schemas

### Integration Tests (TODO)
- API endpoint validation
- Payment gateway mock testing
- Notification delivery

### E2E Tests (TODO)
- Complete SOS to payment flow
- Provider registration to dashboard
- Admin verification workflow

## Deployment

### Production Checklist
- [ ] Enable authentication system
- [ ] Connect real payment gateway
- [ ] Setup database (Supabase/Neon)
- [ ] Configure email service
- [ ] Setup SMS notifications (Twilio)
- [ ] Enable push notifications
- [ ] Setup monitoring & analytics
- [ ] Configure CDN for assets
- [ ] Setup error tracking (Sentry)
- [ ] Enable rate limiting

## Environment Variables (Required)

```env
# Payment Gateway
NEXT_PUBLIC_STRIPE_KEY=
STRIPE_SECRET_KEY=

# SMS/Email
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
SENDGRID_API_KEY=

# Database
DATABASE_URL=
DATABASE_SSL=true

# Maps (if using)
NEXT_PUBLIC_MAPBOX_TOKEN=

# Admin
NEXT_PUBLIC_ADMIN_PIN=1234
```

## Roadmap

### Phase 1 (Current)
- ✅ UI/UX implementation
- ✅ Component system
- ✅ API route structure
- ⏳ Database integration

### Phase 2
- Real-time WebSocket integration
- Payment gateway integration
- SMS/Email notifications
- Provider verification workflow
- Analytics dashboard

### Phase 3
- Mobile app (React Native)
- Insurance integration
- Referral program
- Subscription tiers
- API for third-party integrations

### Phase 4
- AI-powered price optimization
- Predictive demand analytics
- Advanced fraud detection
- Multi-language support
- Regional expansion tools

## Contributing

### Code Standards
- Use TypeScript for type safety
- Follow shadcn/ui patterns for components
- Use Tailwind utilities (no custom CSS)
- Add PropTypes for dynamic components
- Document complex logic with comments

### Branch Strategy
- `main`: Production-ready code
- `develop`: Integration branch
- `feature/*`: Feature development
- `bugfix/*`: Bug fixes
- `docs/*`: Documentation updates

## Support

For documentation questions or issues:
1. Check SYSTEM_ARCHITECTURE.md
2. Review component PropTypes
3. Check API route comments
4. Review existing implementations

## License

Proprietary - Tireno Roadside Assistance System
