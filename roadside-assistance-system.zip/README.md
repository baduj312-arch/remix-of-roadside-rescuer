# Tireno Roadside Assistance System

A comprehensive mobile-first platform connecting drivers with mechanics, vulcanizers, tow truck operators, and emergency services in real-time. Featuring live SOS requests, provider bidding, real-time tracking, verified provider profiles, safety features, and payment processing.

**Live Demo**: [tireno.vercel.app](https://tireno.vercel.app)

## Quick Start

### Prerequisites
- Node.js 18+
- pnpm (or npm/yarn)

### Installation

```bash
# Clone the repository
git clone https://github.com/baduj312-arch/v0-roadside-assistance-system.git
cd v0-roadside-assistance-system

# Install dependencies
pnpm install

# Start development server
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) to view the app.

## System Architecture

Complete documentation available in [SYSTEM_ARCHITECTURE.md](./SYSTEM_ARCHITECTURE.md).

**Key Components**:
- Driver Dashboard: Request assistance, view providers, track jobs, manage payments
- Provider Management: Registration, performance dashboard, SOS bidding
- Admin Dashboard: PIN-protected (1234) real-time monitoring and analytics
- Real-time Bidding: 3-minute countdown with provider ranking
- Live Tracking: Route visualization, status timeline, safety features
- Payment System: Multiple payment methods with escrow protection

## Demo Walkthrough

### For Drivers
1. **Home** (`/`): View available services and nearby providers
   - Tap SOS button to request immediate assistance
   - Browse and filter nearby mechanics/tow trucks
   
2. **SOS Request** (`/sos`): Select service type and auto-detect location
   
3. **Live Bidding** (`/bidding`): Receive real-time bids from providers
   - 3-minute countdown timer
   - Provider ranking by trust score
   - Accept best bid to start tracking
   
4. **Live Tracking** (`/tracking`): Monitor job progress in real-time
   - Visual route map
   - Job status timeline
   - In-app chat with provider
   - 10-minute free guarantee countdown
   
5. **Payment** (`/payment`): Secure payment processing
   - Multiple payment methods (MoMo, Visa, Cash, Wallet)
   - Itemized breakdown
   - Escrow protection
   
6. **Rating** (`/rating`): Provide feedback
   - 5-star rating
   - Category ratings
   - Written review

### For Providers
1. **Registration** (`/provider-register`): 4-step onboarding
   - Personal verification
   - Service selection
   - Fake Mechanic Shield verification
   
2. **Dashboard** (`/provider-dashboard`): Monitor performance
   - Earnings and payouts
   - Trust score breakdown
   - Live SOS requests
   - Rating analytics

### For Admin
1. **Dashboard** (`/admin`): PIN: `1234`
   - Real-time SOS map
   - Provider verification queue
   - Revenue tracking
   - System broadcasts
   - Fraud alerts

## Key Features

### Core Functionality
- ✅ Real-time SOS request broadcasting
- ✅ Provider bidding with countdown timer
- ✅ Live job tracking with route visualization
- ✅ In-app messaging system
- ✅ Integrated payment processing
- ✅ Rating and review system
- ✅ Wallet and transaction management

### Safety & Trust
- ✅ Trust Score algorithm (Rating 50% + Success Rate 30% + Response Time 20%)
- ✅ Ride-or-Tow safety tracker with shareable links
- ✅ Fake Mechanic Shield multi-step verification
- ✅ Escrow-protected payments
- ✅ Dispute resolution system

### Admin Features
- ✅ Real-time SOS map visualization
- ✅ Provider verification queue
- ✅ Revenue and commission tracking
- ✅ User growth analytics
- ✅ Fraud detection alerts
- ✅ System-wide broadcast capability

## Technology Stack

- **Frontend**: Next.js 16 (App Router)
- **UI Components**: shadcn/ui with Radix UI
- **Styling**: Tailwind CSS v4
- **Animations**: Framer Motion
- **Forms**: React Hook Form + Zod
- **Type Safety**: TypeScript

## API Endpoints

### SOS System
```
POST /api/sos              # Create SOS request
GET  /api/sos?id=sosId     # Get SOS details
```

### Bidding System
```
POST /api/bids             # Submit provider bid
GET  /api/bids?sosId=id    # Get bids for SOS
```

### Payment System
```
POST /api/payments         # Process payment
GET  /api/payments?jobId=id # Get transaction details
```

### Notifications
```
GET  /api/notifications?userId=id           # Get notifications
POST /api/notifications                     # Create notification
PATCH /api/notifications                    # Mark as read
```

## Customization

### Trust Score Weights
Edit in `lib/constants.ts`:
```typescript
TRUST_SCORE_WEIGHTS = {
  rating: 0.5,
  successRate: 0.3,
  responseTime: 0.2,
}
```

### Commission Structure
Edit in `lib/constants.ts`:
```typescript
COMMISSIONS = {
  standard: 15,    // 15%
  premium: 10,     // 10%
  platinum: 5,     // 5%
}
```

### Service Types
Edit in `lib/constants.ts`:
```typescript
SERVICE_TYPES = {
  mechanic: { label: 'Mechanic', icon: 'Wrench' },
  vulcanizer: { label: 'Vulcanizer', icon: 'Hammer' },
  towing: { label: 'Towing', icon: 'Truck' },
  // Add more...
}
```

## Development

### File Structure
```
/app              # Next.js pages & API routes
/components       # Reusable React components
/hooks            # Custom React hooks
/lib              # Utilities & constants
/public           # Static assets
/styles           # Global styles
```

### Build & Deploy

```bash
# Build for production
pnpm build

# Run production build locally
pnpm start

# Lint code
pnpm lint
```

## Testing Demo Features

### No Authentication Required
All features work in demo mode without login. Mock data is used throughout.

### Test Different User Types
- **Driver**: Access home, SOS, bidding, tracking, payments
- **Provider**: Visit `/provider-register` and `/provider-dashboard`
- **Admin**: Visit `/admin` (PIN: 1234)

### Mobile Optimization
Test on mobile viewport (375px width) for optimal experience.

## Future Enhancements

- Real-time WebSocket integration for live updates
- Payment gateway integration (Stripe, MoMo)
- SMS/Email notifications (Twilio, SendGrid)
- Insurance integration
- Referral program
- Subscription tiers
- Mobile app (React Native)
- Multi-language support

## Contributing

1. Create feature branch: `git checkout -b feature/amazing-feature`
2. Commit changes: `git commit -m 'Add amazing feature'`
3. Push to branch: `git push origin feature/amazing-feature`
4. Open Pull Request

## Support & Documentation

- **Architecture Docs**: [SYSTEM_ARCHITECTURE.md](./SYSTEM_ARCHITECTURE.md)
- **Component Guide**: Check `components/` folder for component exports
- **API Documentation**: Check `app/api/` for endpoint details
- **Utilities**: Check `lib/trust-score.ts` for algorithm details

## License

Proprietary - Tireno Roadside Assistance System. All rights reserved.

---

**Built with [v0](https://v0.app)** - Next.js development platform

<a href="https://v0.app/chat/api/kiro/clone/baduj312-arch/v0-roadside-assistance-system" alt="Open in Kiro"><img src="https://pdgvvgmkdvyeydso.public.blob.vercel-storage.com/open%20in%20kiro.svg?sanitize=true" /></a>
