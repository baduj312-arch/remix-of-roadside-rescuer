/**
 * Trust Score Algorithm
 * 
 * Formula: (Rating × 0.5) + (Success Rate × 0.3) + (Response Time Score × 0.2)
 * 
 * Weights:
 * - Rating (50%): Average customer rating 0-5, normalized to 0-100
 * - Success Rate (30%): Percentage of completed jobs 0-100
 * - Response Time Score (20%): Based on average response time
 */

export interface TrustScoreFactors {
  rating: number // 0-5
  successRate: number // 0-100
  responseTime: number // minutes
  totalJobs: number
  completedJobs: number
  cancellations: number
}

export interface TrustScoreBreakdown {
  ratingScore: number
  successRateScore: number
  responseTimeScore: number
  totalScore: number
  factors: TrustScoreFactors
}

/**
 * Calculate trust score based on provider metrics
 */
export function calculateTrustScore(factors: TrustScoreFactors): TrustScoreBreakdown {
  // Normalize rating from 0-5 scale to 0-100 scale
  const ratingScore = (factors.rating / 5) * 100

  // Success rate is already 0-100
  const successRateScore = factors.successRate

  // Calculate response time score (higher is better)
  // Target: 5 minutes or less = 100
  // 10 minutes = 80, 15 minutes = 60, etc.
  const responseTimeScore = Math.max(0, Math.min(100, 100 - (factors.responseTime - 5) * 4))

  // Apply weights
  const totalScore = Math.round(
    ratingScore * 0.5 + successRateScore * 0.3 + responseTimeScore * 0.2
  )

  return {
    ratingScore: Math.round(ratingScore),
    successRateScore: Math.round(successRateScore),
    responseTimeScore: Math.round(responseTimeScore),
    totalScore,
    factors,
  }
}

/**
 * Get trust score tier based on score value
 */
export function getTrustTier(score: number): string {
  if (score >= 95) return 'Platinum'
  if (score >= 90) return 'Gold'
  if (score >= 80) return 'Silver'
  if (score >= 70) return 'Bronze'
  if (score >= 60) return 'Standard'
  return 'New Provider'
}

/**
 * Get trust score color
 */
export function getTrustScoreColor(score: number): string {
  if (score >= 90) return 'text-green-500'
  if (score >= 70) return 'text-yellow-500'
  return 'text-red-500'
}

/**
 * Get trust score badge color
 */
export function getTrustScoreBgColor(score: number): string {
  if (score >= 90) return 'bg-green-500/10 border-green-500/30'
  if (score >= 70) return 'bg-yellow-500/10 border-yellow-500/30'
  return 'bg-red-500/10 border-red-500/30'
}

/**
 * Calculate success rate from job data
 */
export function calculateSuccessRate(
  completedJobs: number,
  totalJobs: number,
  cancellations: number
): number {
  if (totalJobs === 0) return 0
  return Math.round(((completedJobs - cancellations) / totalJobs) * 100)
}

/**
 * Get recommendation text based on trust score
 */
export function getTrustScoreMessage(score: number): string {
  if (score >= 95) return 'Highly trusted provider. Excellent service record.'
  if (score >= 90) return 'Very reliable provider with strong track record.'
  if (score >= 80) return 'Reliable provider. Generally positive feedback.'
  if (score >= 70) return 'Decent service record. Some room for improvement.'
  return 'New or developing provider. Check reviews before booking.'
}
