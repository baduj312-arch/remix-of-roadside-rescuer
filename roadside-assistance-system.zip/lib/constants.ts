/**
 * Tireno System Constants
 */

export const CURRENCY = 'GH₵'
export const CURRENCY_CODE = 'GHS'

// Service Types
export const SERVICE_TYPES = {
  mechanic: { label: 'Mechanic', icon: 'Wrench' },
  vulcanizer: { label: 'Vulcanizer', icon: 'Hammer' },
  towing: { label: 'Towing', icon: 'Truck' },
  battery: { label: 'Battery', icon: 'Zap' },
  fuel: { label: 'Fuel Delivery', icon: 'Droplet' },
  locksmith: { label: 'Locksmith', icon: 'Lock' },
} as const

// Payment Methods
export const PAYMENT_METHODS = {
  momo: { label: 'Mobile Money (MTN/Airtel)', icon: 'Phone' },
  visa: { label: 'Debit/Credit Card', icon: 'CreditCard' },
  cash: { label: 'Pay at Location', icon: 'Banknote' },
  wallet: { label: 'Tireno Wallet', icon: 'Wallet' },
} as const

// Job Status
export const JOB_STATUS = {
  pending: 'Pending',
  accepted: 'Accepted',
  enroute: 'En Route',
  arrived: 'Arrived',
  inprogress: 'In Progress',
  completed: 'Completed',
  cancelled: 'Cancelled',
  disputed: 'Disputed',
} as const

// Notification Types
export const NOTIFICATION_TYPES = {
  bid: { label: 'Bid Received', color: 'blue' },
  sos: { label: 'SOS Update', color: 'red' },
  payment: { label: 'Payment', color: 'green' },
  message: { label: 'Message', color: 'purple' },
  rating: { label: 'Rating', color: 'yellow' },
  system: { label: 'System', color: 'gray' },
} as const

// Bidding Configuration
export const BIDDING_TIMEOUT = 180 // 3 minutes in seconds
export const MAX_BIDS_DISPLAYED = 5
export const AUTO_ACCEPT_BEST_BID = false

// Pricing Configuration
export const BASE_PRICES = {
  mechanic: { min: 50, max: 200 },
  vulcanizer: { min: 30, max: 100 },
  towing: { min: 100, max: 500 },
  battery: { min: 80, max: 150 },
  fuel: { min: 20, max: 50 },
  locksmith: { min: 60, max: 150 },
} as const

// Trust Score Configuration
export const TRUST_SCORE_WEIGHTS = {
  rating: 0.5,
  successRate: 0.3,
  responseTime: 0.2,
} as const

// Admin PIN for demo
export const ADMIN_PIN = '1234'

// Feature Flags
export const FEATURES = {
  rideOrTow: true,
  fakeVerification: true,
  escrow: true,
  disputes: true,
  ratings: true,
  wallet: true,
  referrals: false, // Coming soon
  insurance: false, // Coming soon
} as const

// Commission Structure (percentage)
export const COMMISSIONS = {
  standard: 15, // 15% for standard providers
  premium: 10, // 10% for premium providers
  platinum: 5, // 5% for platinum providers
} as const

// Response Time Targets (minutes)
export const RESPONSE_TIME_TARGETS = {
  excellent: 5,
  good: 10,
  acceptable: 15,
  slow: 20,
} as const

// SOS Message Templates
export const SOS_TEMPLATES = {
  breakdown: 'My vehicle has broken down',
  tire: 'I have a flat tire',
  battery: 'My battery is dead',
  fuel: 'I ran out of fuel',
  accident: 'I was in an accident',
  locked: 'I locked my keys in the car',
  other: 'Other issue',
} as const
