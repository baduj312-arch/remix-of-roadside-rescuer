/**
 * Seed Data for Tireno Demo
 * 
 * This file contains mock data for development and demonstration purposes.
 * Replace with real database queries in production.
 */

import { type Provider } from '@/components/tireno/provider-card'

export const mockUsers = [
  {
    id: '1',
    name: 'Ama Osei',
    phone: '+233501234567',
    email: 'ama@example.com',
    type: 'driver' as const,
    wallet: 250.50,
    trustScore: 98,
  },
  {
    id: '2',
    name: 'Kwame Auto Services',
    phone: '+233541234567',
    email: 'kwame@autoservices.com',
    type: 'provider' as const,
    wallet: 1250.50,
    trustScore: 94,
  },
  {
    id: '3',
    name: 'Joseph Mechanics',
    phone: '+233551234567',
    email: 'joseph@mechanics.com',
    type: 'provider' as const,
    wallet: 850.00,
    trustScore: 88,
  },
]

export const mockProviders: Provider[] = [
  {
    id: '1',
    name: 'Kwame Auto Services',
    initials: 'KA',
    rating: 4.8,
    reviewCount: 156,
    trustScore: 94,
    verified: true,
    serviceType: 'mechanic',
    eta: '4 min',
    price: 85,
    successRate: 98,
    jobsToday: 5,
    about: 'Professional mechanic with 10+ years experience. Specializes in engine repairs and transmission work.',
    location: 'Accra Central',
    responseTime: 4,
  },
  {
    id: '2',
    name: 'Joseph Mechanics',
    initials: 'JM',
    rating: 4.6,
    reviewCount: 89,
    trustScore: 88,
    verified: true,
    serviceType: 'mechanic',
    eta: '7 min',
    price: 75,
    successRate: 95,
    jobsToday: 3,
    about: 'Reliable mechanic offering general repairs and maintenance. Available 24/7.',
    location: 'Tema',
    responseTime: 7,
  },
  {
    id: '3',
    name: 'Quick Fix Auto',
    initials: 'QF',
    rating: 4.5,
    reviewCount: 67,
    trustScore: 85,
    verified: true,
    serviceType: 'mechanic',
    eta: '10 min',
    price: 65,
    successRate: 92,
    jobsToday: 2,
    about: 'Fast and affordable auto repairs. Quick turnaround times.',
    location: 'Kasoa',
    responseTime: 10,
  },
  {
    id: '4',
    name: 'MJ Towing Services',
    initials: 'MJ',
    rating: 4.7,
    reviewCount: 124,
    trustScore: 91,
    verified: true,
    serviceType: 'towing',
    eta: '8 min',
    price: 150,
    successRate: 96,
    jobsToday: 4,
    about: 'Professional towing and roadside assistance. Safe handling guaranteed.',
    location: 'Greater Accra',
    responseTime: 8,
  },
  {
    id: '5',
    name: 'Tire Master Ghana',
    initials: 'TM',
    rating: 4.4,
    reviewCount: 92,
    trustScore: 82,
    verified: true,
    serviceType: 'vulcanizer',
    eta: '6 min',
    price: 45,
    successRate: 94,
    jobsToday: 8,
    about: 'Tire repairs, balancing, and replacement services.',
    location: 'Tema West',
    responseTime: 6,
  },
]

export const mockNotifications = [
  {
    id: '1',
    type: 'bid' as const,
    title: 'New Bid Received',
    message: 'Kwame Auto Services bid GH₵85 for your repair',
    read: false,
    createdAt: new Date(Date.now() - 5 * 60000), // 5 minutes ago
  },
  {
    id: '2',
    type: 'sos' as const,
    title: 'Provider En Route',
    message: 'Joseph Mechanics is on the way. ETA 7 minutes',
    read: false,
    createdAt: new Date(Date.now() - 15 * 60000), // 15 minutes ago
  },
  {
    id: '3',
    type: 'payment' as const,
    title: 'Payment Successful',
    message: 'Payment of GH₵75.00 completed for job TRN-A7B3X2',
    read: true,
    createdAt: new Date(Date.now() - 60 * 60000), // 1 hour ago
  },
  {
    id: '4',
    type: 'message' as const,
    title: 'Message from Joseph',
    message: 'Hi, I am arriving soon. Parked near the main gate.',
    read: true,
    createdAt: new Date(Date.now() - 2 * 60 * 60000), // 2 hours ago
  },
  {
    id: '5',
    type: 'rating' as const,
    title: 'Rate Your Experience',
    message: 'How was your service with Joseph Mechanics?',
    read: true,
    createdAt: new Date(Date.now() - 24 * 60 * 60000), // 1 day ago
  },
]

export const mockJobHistory = [
  {
    id: 'TRN-A7B3X2',
    serviceType: 'mechanic',
    provider: 'Joseph Mechanics',
    providerId: '2',
    status: 'completed',
    date: '2024-05-18',
    amount: 75,
    rating: 4.5,
    review: 'Great service, very professional and quick.',
  },
  {
    id: 'TRN-X9K2M5',
    serviceType: 'towing',
    provider: 'MJ Towing Services',
    providerId: '4',
    status: 'completed',
    date: '2024-05-15',
    amount: 150,
    rating: 5,
    review: 'Excellent service. Handled my car with care.',
  },
  {
    id: 'TRN-B3L7P1',
    serviceType: 'vulcanizer',
    provider: 'Tire Master Ghana',
    providerId: '5',
    status: 'completed',
    date: '2024-05-10',
    amount: 45,
    rating: 4,
    review: 'Good service, though took a bit longer than expected.',
  },
  {
    id: 'TRN-W2Q8N4',
    serviceType: 'mechanic',
    provider: 'Kwame Auto Services',
    providerId: '1',
    status: 'completed',
    date: '2024-05-05',
    amount: 85,
    rating: 5,
    review: 'Professional mechanic. Fixed the issue completely.',
  },
]

export const mockWalletTransactions = [
  {
    id: 'TXN-001',
    type: 'topup' as const,
    description: 'Wallet top-up',
    amount: 100,
    method: 'visa',
    date: '2024-05-18',
    status: 'completed',
  },
  {
    id: 'TXN-002',
    type: 'payment' as const,
    description: 'Payment for TRN-A7B3X2',
    amount: -75,
    method: 'wallet',
    date: '2024-05-18',
    status: 'completed',
  },
  {
    id: 'TXN-003',
    type: 'topup' as const,
    description: 'Wallet top-up',
    amount: 50,
    method: 'momo',
    date: '2024-05-15',
    status: 'completed',
  },
]

export const mockEmergencyContacts = [
  {
    id: '1',
    name: 'Mom',
    phone: '+233501111111',
    relationship: 'Mother',
  },
  {
    id: '2',
    name: 'Dad',
    phone: '+233502222222',
    relationship: 'Father',
  },
  {
    id: '3',
    name: 'Sister Ama',
    phone: '+233503333333',
    relationship: 'Sister',
  },
]

export const mockVehicles = [
  {
    id: '1',
    make: 'Toyota',
    model: 'Corolla',
    year: 2021,
    color: 'Silver',
    licensePlate: 'GR-5432-21',
    vin: 'JTNZ84C44J5032587',
    insuranceProvider: 'AXA Insurance Ghana',
    policyNumber: 'AXA-2024-GH-5432',
  },
]

export const mockSavedLocations = [
  {
    id: '1',
    name: 'Home',
    address: '123 Osu Street, Accra',
    latitude: 5.6037,
    longitude: -0.1870,
  },
  {
    id: '2',
    name: 'Work',
    address: 'Osu Office Park, Accra',
    latitude: 5.6050,
    longitude: -0.1865,
  },
]

export const mockReviews = [
  {
    id: '1',
    reviewer: 'Alex K.',
    rating: 5,
    date: '2024-05-10',
    text: 'Excellent service! Fixed my car in no time. Highly recommended.',
    service: 'Engine Repair',
  },
  {
    id: '2',
    reviewer: 'Nana A.',
    rating: 5,
    date: '2024-05-08',
    text: 'Professional and punctual. Great experience overall.',
    service: 'Oil Change',
  },
  {
    id: '3',
    reviewer: 'Esi M.',
    rating: 4,
    date: '2024-05-05',
    text: 'Good work, but could have communicated better about timing.',
    service: 'Brake Inspection',
  },
]

export const mockDisputes = [
  {
    id: 'DISP-001',
    jobId: 'TRN-OLD123',
    provider: 'Old Provider',
    amount: 50,
    reason: 'Service not completed as agreed',
    status: 'resolved',
    createdAt: '2024-04-01',
  },
]
